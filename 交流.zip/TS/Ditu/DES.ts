// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import ComponentBase from "../Message/ComponentBase";
import GeZiManager from "../Message/GeZiManager";
import { Message } from "../Message/Message";
import realThing from "../realThing";
import turn from "../turn";
import DESManager from "./DESManager";

const {ccclass, property} = cc._decorator;

@ccclass
export default class DES extends ComponentBase{
i:number=0;
   start(){
     DESManager.DES.push(this) ;
  turn.YuanGong.push(this);
    }


    ReceiveMessage(message:Message) {
        if(this.node.getComponent(realThing).ZB==message.Command){
this.node.active=false;

        }
    }




turnPass(){
  this.i+=1;
if(this.i==24){
  this.i=0;
  GeZiManager.DLBX(this.node.getComponent(realThing).ZB);
}

console.log(this.i);
}






  }





