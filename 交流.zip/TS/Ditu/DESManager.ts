// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import ManagerBase from "../Message/ManagerBase";
import { Message } from "../Message/Message";
import DES from "./DES";

const {ccclass, property} = cc._decorator;

@ccclass
export default class DESManager extends ManagerBase {

   static DES:DES[]=[];


static Des(ZB:number){

    for(let mannger of this.DES){
   
        let a=""
        let message=new Message(a,ZB,5)
        mannger.ReceiveMessage(message);}


    }
}

