

import ComponentBase from "../Message/ComponentBase";
import GeZiManager from "../Message/GeZiManager";
import { Message } from "../Message/Message";

import MessageCenter from "../Message/MessageCenter";
import UIManager from "../Message/UIManager";

import weapon from "../equipment/weapon/weapon";
import state from "../state";
import turn from "../turn";
import GeZi from "./GeZi";

const {ccclass, property} = cc._decorator;

@ccclass
export default class DGZ extends ComponentBase {

    Touch(){

    switch (state.ST) {
      case 0: 
            
      MessageCenter.MakeMessage("UIManager","change",2)
      
      
   GeZiManager.GeZis.push(this.node.getComponent(GeZi).ZB);
  GeZiManager.GeZi=this.node.getComponent(GeZi).ZB;
   GeZiManager.changeChoose();
         break;
       
       
       
         case 1:
          let c=new Message("",GeZiManager.GeZis,1);
          for(let manager of GeZiManager.YuanGong){
          
          
              manager.red();
          
             manager.ReceiveMessage(c);
          }
           
        
        
        GeZiManager.GeZi=this.node.getComponent(GeZi).ZB;

this.node.getComponent(GeZi).blue();

          MessageCenter.MakeMessage("UIManager","change",2)
         
         
          MessageCenter.MakeMessage("AM",turn.turn,"getC")
         GeZiManager.PCP.weapon.getComponent(weapon).ac();
         
         
          break;
        
         case 2:
            MessageCenter.MakeMessage("AM",turn.turn,"getZB")
           
            
            
             MessageCenter.MakeMessage("UIManager","change",-1);
            for(let manager of GeZiManager.YuanGong){
            
            manager.getFar(4);
            if(GeZiManager.BanMove.includes(manager.ZB)||GeZiManager.DL[0].includes(manager.ZB)){
               manager.red()}}
    GeZiManager.GeZi= this.node.getComponent(GeZi).ZB; 
this.node.getComponent(GeZi).blue();
MessageCenter.MakeMessage("UIManager","change",2)
            
            break;
      
      
      
      
      case 10:  MessageCenter.MakeMessage("UIManager","change",-1);

      for(let manager of GeZiManager.YuanGong){
let a=new Message("",[65],-1)
          manager.ReceiveMessage(a) ;   
}
MessageCenter.MakeMessage("AM",turn.turn,"getZB")

for(let manager of GeZiManager.YuanGong){
manager.getFar(5);}

GeZiManager.GeZi= this.node.getComponent(GeZi).ZB; 
this.node.getComponent(GeZi).blue();;
  
MessageCenter.MakeMessage("UIManager","change",2)
      
      break;
      
            case 11:
               MessageCenter.MakeMessage("UIManager","change",-1);

               for(let manager of GeZiManager.YuanGong){
       let a=new Message("",[65],-1)
                   manager.ReceiveMessage(a)    
       }
       MessageCenter.MakeMessage("AM",turn.turn,"getZB")
       
       for(let manager of GeZiManager.YuanGong){
         manager.getFar(3);
       if(GeZiManager.BanMove.includes(manager.ZB)){
       
           
       }else{  manager.red(); }
           }
 GeZiManager.GeZi= this.node.getComponent(GeZi).ZB; 
        this.node.getComponent(GeZi).blue();;
           
        MessageCenter.MakeMessage("UIManager","change",2)
      
      
      
      
      
      
      
            break;
      
      
      
      
      
            default:
         break;
    }   
        
         
        
        
        
        
        }
        
        
        
        
        }







