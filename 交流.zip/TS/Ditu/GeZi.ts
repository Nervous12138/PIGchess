// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import ComponentBase from "../Message/ComponentBase";
import FState from "../Message/FState";
import GeZiManager from "../Message/GeZiManager";
import { Message } from "../Message/Message";
import MessageCenter from "../Message/MessageCenter";
import UIManager from "../Message/UIManager";


const {ccclass, property} = cc._decorator;

@ccclass
export default class GeZi extends ComponentBase {

    @property
   ZB:number=0;
   
   @property
   X:number=0;
 
   @property
  Y:number=0;
  @property
DiXing:String="grass";
  @property(cc.Node)
    standBY: cc.Node[] = null;


   

blue(){this.node.color=cc.color(48,48,255,255);this.node.getComponent(cc.Button).enabled=false;this.node.opacity=255;}
red(){this.node.color=cc.color(255,12,12,255),this.node.getComponent(cc.Button).enabled=false;this.node.opacity=255;}
green(){this.node.color=cc.color(54,231,158,255);this.node.getComponent(cc.Button).enabled=true;this.node.opacity=166;}
black(){this.node.color=cc.color(0,0,0,255),this.node.getComponent(cc.Button).enabled=false;this.node.opacity=255;}
null(){this.node.color=cc.color(255,255,255,0),this.node.getComponent(cc.Button).enabled=false;this.node.opacity=255;}



       


    
 onLoad(){
    GeZiManager.YuanGong.push(this)



}










    start () {

      let a:number[]=[5,6,7]
     if(a.includes(this.X)){this.red();}

this.node.zIndex=8-(this.Y+0.5);
}


 getFar(dis:number){
let x;
let y;
    
        if(GeZiManager.GeZi%8==0){x=8}else {x=GeZiManager.GeZi%8;}
    y=Math.ceil(GeZiManager.GeZi/8);
    
if(Math.abs(x-this.X)+Math.abs(y-this.Y)>=dis){ this.red();}
else{this.green();}

}













    ReceiveMessage(message:Message){
switch(message.Command){
   
 case GeZiManager.bule:
    let XS:number[]=[2,3,4]
    let YS:number[]=[];

    
        for(let ZB of GeZiManager.bule ){
           
           let x 
           let y
            if(ZB%8==0){x=8}else {x=ZB%8;}
            XS.push(x);
           
            y=Math.floor(ZB/8)+1;
            YS.push(y);

if(XS.includes(this.X)){
    this.red();
}

if(YS.includes(this.Y)){
    this.red();
}


}

if(GeZiManager.red.includes(this.ZB)){
    this.black();
}
GeZiManager.Gtree();
break;
















case GeZiManager.red:
     XS=[5,6,7]
     YS=[];
   
    
        for(let ZB of GeZiManager.red ){
           
           let x
            if(ZB%8==0){x=8}else {x=ZB%8;}
            XS.push(x);
            let y
            y=Math.floor(ZB/8)+1;
            YS.push(y);
       
if(XS.includes(this.X)){
    

    this.red();
   
}
if(YS.includes(this.Y)){
    this.red();
}



}
if(GeZiManager.bule.includes(this.ZB)){

    this.black();}
GeZiManager.Gtree();


    break;

















default:
if(message.Command[0]==65){
switch(message.Content){
    case -1:this.red();
    break ;   
    case 0:this.null();
break ;   
case 1:this.green();
break ;
case 2:this.blue();
break ;

}
}
if(message.Command.includes(this.ZB)){
    switch(message.Content){
        case -1:this.red();
        break ;   
        case 0:this.null();
    break ;   
    case 1:this.green();
    break ;   
    case 2:this.blue();
    break ;
case 5: this.black();
break;
}




}






}







}














  








}
   

