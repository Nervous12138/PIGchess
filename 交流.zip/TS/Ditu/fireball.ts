// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import GeZiManager from "../Message/GeZiManager";
import { Message } from "../Message/Message";
import MessageCenter from "../Message/MessageCenter";
import realThing from "../realThing";
import turn from "../turn";
import DES from "./DES";

const {ccclass, property} = cc._decorator;

@ccclass
export default class fireball extends realThing {
rond:number=0;
   turn:number=0;
   a:number=0;
   
   @property(cc.SpriteAtlas)
   Atlas:cc.SpriteAtlas=null;
  
  
   start() {
    turn.YuanGong.push(this)  ; 
  this.rond=turn.round;

}
   
   
 BZ(){
MessageCenter.MakeMessage("AM",turn.turn,"getC");
MessageCenter.MakeSHMessage("AM",[this.ZB],2,GeZiManager.PCP,"mofa")
this.node.destroy();
this.turn=7;
GeZiManager.DLBZ(this.ZB);
}

turnPass() {
 
if(turn.round==this.rond+1&&turn.turn==this.turn){

this.BZ();
}

    }






  ReceiveMessage(message: Message): void {
    
  }

}












