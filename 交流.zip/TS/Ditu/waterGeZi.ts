// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import GeZiManager from "../Message/GeZiManager";
import { Message } from "../Message/Message";
import state from "../state";
import GeZi from "./GeZi";

const {ccclass, property} = cc._decorator;

@ccclass
export default class  waterGZ extends GeZi {

    

   
 
    
 
 
 
 

@property
DiXing:String="water";


 





start(){
  console.log("afa")  
}



     


  











  
 
 
 
        
 
 
 
 
 
    


    ReceiveMessage(message:Message){
        
        if(state.state==0||state.ST==2){this.node.active=false}else{
            this.node.active=true;
        
        
        
           
                if(message.Command[0]==65){
                    switch(message.Content){
                        case -1:this.red();
                        break ;   
                        case 0:this.null();
                    break ;   
                    case 1:this.green();
                    break ;
                    case 2:this.blue();
                    break ;
                    
                    }
                    }
                    if(message.Command.includes(this.ZB)){
                        switch(message.Content){
                            case -1:this.red();
                            break ;   
                            case 0:this.null();
                        break ;   
                        case 1:this.green();
                        break ;   
                        case 2:this.blue();
                        break ;
                    case 5: this.black;
                    break;
                    }
               
               
               
               
               
               
               
               
               }}}}