// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import DES from "../Ditu/DES";
import DESManager from "../Ditu/DESManager";
import fireball from "../Ditu/fireball";
import character from "../character";
import realThing from "../realThing";
import turn from "../turn";
import ComponentBase from "./ComponentBase";
import GeZiManager from "./GeZiManager";
import ManagerBase from "./ManagerBase";
import { Message } from "./Message";
import MessageCenter from "./MessageCenter";
import Pchange from "./Pchange";
import { SHMessage } from "./xinxi/SHMessage";

const {ccclass, property} = cc._decorator;

@ccclass
export default class AnimalManager extends ManagerBase {
 P1SN:number=0;
 P2SN:number=0;   
 P3SN:number=0;
 P4SN:number=0;
 P5SN:number=0;
 P6SN:number=0;
@property(cc.Prefab)
 P1:cc.Prefab;
 @property(cc.Prefab)
 P2:cc.Prefab;
 @property(cc.Prefab)
 P3:cc.Prefab;
 @property(cc.Prefab)
 P4:cc.Prefab;
 @property(cc.Prefab)
 P5:cc.Prefab;
 @property(cc.Prefab)
 P6:cc.Prefab;


messageType: String="AM"

YuanGong:realThing[]=[];






@property(cc.Prefab)
tree:cc.Prefab;
@property(cc.Prefab)
rock:cc.Prefab;
@property(cc.Prefab)
DL:cc.Prefab;
@property(cc.Prefab)
fireball:cc.Prefab;



makeDL(ZB:number){
let DL=cc.instantiate(this.DL)
DESManager.DES.push (DL.getComponent(DES))
GeZiManager.DL.push([ZB,3+GeZiManager.free])

DL.setParent(this.node)
DL.getComponent(realThing).ghost=true;
DL.getComponent(realThing).ZB=ZB;
DL.getComponent(realThing).setXY();
DL.getComponent(realThing).moveto(0,ZB)

}
makeTree(ZB:number){

let tree=cc.instantiate(this.tree)
tree.setParent(this.node)
tree.getComponent(realThing).ZB=ZB;
tree.getComponent(realThing).WD=true;
tree.getComponent(realThing).M=-1;

tree.getComponent(realThing).moveto(0,ZB)
this.node.getComponent(AnimalManager).YuanGong.push(tree.getComponent(realThing))
tree.getComponent(realThing).HP=2;
}
makeRock(ZB:number){


let rock=cc.instantiate(this.rock)
rock.setParent(this.node)
rock.getComponent(realThing).ZB=ZB;
rock.getComponent(realThing).WD=true;
rock.getComponent(realThing).M=0;
GeZiManager.rock.push(ZB);
rock.getComponent(realThing).tt="rock"
rock.getComponent(realThing).moveto(0,ZB)
this.node.getComponent(AnimalManager).YuanGong.push(rock.getComponent(realThing))
rock.getComponent(realThing).HP=4;
}

makeFireball(ZB:number){

    let fireball1=cc.instantiate(this.fireball)
    fireball1.setParent(this.node);
    fireball1.getComponent(realThing).ZB=ZB;
    
    fireball1.getComponent(fireball).turn=turn.turn;

    fireball1. getComponent(realThing).setXY();
    fireball1.getComponent(realThing).moveto(0,ZB);
GeZiManager.shanchu(GeZiManager.BanMove,ZB)



}





start(){
   MessageCenter.addReceive(this);









    let P1=cc.instantiate(this.P1)
    P1.setParent(this.node)
    P1.active=false;
   
    let P2=cc.instantiate(this.P2)
    P2.setParent(this.node)
    P2.active=false;
    
    let P3=cc.instantiate(this.P3)
    P3.setParent(this.node)
    P3.active=false;
    
    let P4=cc.instantiate(this.P4)
    P4.setParent(this.node)
    P4.active=false;
    
    let P5=cc.instantiate(this.P5)
    P5.setParent(this.node)
    P5.active=false;
    
    let P6=cc.instantiate(this.P6)
    P6.setParent(this.node)
    P6.active=false;

   GeZiManager. blueP=[ GeZiManager.P1,GeZiManager.P3,GeZiManager.P5];

GeZiManager.redP=[ GeZiManager.P2,GeZiManager.P4,GeZiManager.P6];
    let landnei:number[]=[19,20,21,22,27,28,29,30,35,36,37,38,43,44,45,46];
    let landwai:number[]=[10,11,12,13,14,15,18,23,26,31,34,39,42,47,50,51,52,53,54,55];
    let num1:number;
    let num2:number;
    let num3:number;
    function getRandomInt(min: number, max: number): number {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
      }
    //第一个障碍物,num1是位置
    let t1=getRandomInt(1,10);
    if(t1>=1&&t1<=3)
    {
        let t2=getRandomInt(0,19);
        num1=landwai[t2];
    }
    else
    {
        let t2=getRandomInt(0,15);
        num1=landnei[t2];
    }
    //第二个,num2是位置
    let t3=getRandomInt(1,10);
    if(t3>=1&&t3<=3)
    {
        let t4=getRandomInt(0,19);
        let temp=landwai[t4];
        while(temp==num1+1||temp==num1-1||temp==num1+8||temp==num1-8||temp==num1)
        {
            t4=getRandomInt(0,19);
            temp=landwai[t4];
        }
        num2=temp;
    }
    else
    {
        let t4=getRandomInt(0,15);
        let temp=landnei[t4];
        while(temp==num1+1||temp==num1-1||temp==num1+8||temp==num1-8||temp==num1)
        {
            t4=getRandomInt(0,15);
            temp=landnei[t4];
        }
        num2=temp;
    }
    //第三个,num3是位置
    let t5=getRandomInt(1,10);
    if(t5>=1&&t5<=3)
    {
        let t6=getRandomInt(0,19);
        let temp2=landwai[t6];
        while(temp2==num1+1||temp2==num1-1||temp2==num1+8||temp2==num1-8||temp2==num2+1||temp2==num2-1||temp2==num2+8||temp2==num2-8||temp2==num2||temp2==num1)
        {
            t6=getRandomInt(0,19);
            temp2=landwai[t6];
        }
        num3=temp2;
    }
    else
    {
        let t6=getRandomInt(0,15);
        let temp2=landnei[t6];
        while(temp2==num1+1||temp2==num1-1||temp2==num1+8||temp2==num1-8||temp2==num2+1||temp2==num2-1||temp2==num2+8||temp2==num2-8||temp2==num2||temp2==num1)
        {
            t6=getRandomInt(0,15);
            temp2=landnei[t6];
        }
        num3=temp2;
    }
    console.log(num1+" "+num2+" "+num3);


GeZiManager.trees.push(num1,num2,num3)
console.log(GeZiManager.trees);
this.makeTree(num1);
this.makeTree(num2);
this.makeRock(num3);


GeZiManager.blueBan();




}



 TP(Pturn:number){

switch (Pturn) {
    case 1:this.node.getChildByName("P1").getComponent(character).TP(turn.turn);
    this.node.getChildByName("P1").active=true;
        break;
        case 2:this.node.getChildByName("P2").getComponent(character).TP(turn.turn);console.log("sjdfj")
    this.node.getChildByName("P2").active=true;
        break;
        case 3:this.node.getChildByName("P3").getComponent(character).TP(turn.turn);
    this.node.getChildByName("P3").active=true;
        break;
        case 4:this.node.getChildByName("P4").getComponent(character).TP(turn.turn);
    this.node.getChildByName("P4").active=true;
        break;
        case 5:this.node.getChildByName("P5").getComponent(character).TP(turn.turn);
    this.node.getChildByName("P5").active=true;
        break;
        case 6:this.node.getChildByName("P6").getComponent(character).TP(turn.turn);
    this.node.getChildByName("P6").active=true;this.node.getChildByName("P6").getComponent(character).qi+=1;
 
        break;

    default:
        break;
}

}


ReceiveMessage(message: Message){

    if(message.Type==this.messageType){
        for(let mannger of this.YuanGong){
mannger.ReceiveMessage(message);


    }
}




}















}

