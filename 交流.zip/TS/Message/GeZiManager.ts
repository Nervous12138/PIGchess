// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import DESManager from "../Ditu/DESManager";
import GeZi from "../Ditu/GeZi";
import Slabel from "../UIS/label";
import sideUI from "../UIS/sideUI";
import character from "../character";
import state from "../state";
import turn from "../turn";
import ComponentBase from "./ComponentBase";
import ManagerBase from "./ManagerBase";
import { Message } from "./Message";
import MessageCenter from "./MessageCenter";
import UIManager from "./UIManager";


const {ccclass, property} = cc._decorator;

@ccclass
export default class GeZiManager extends ManagerBase {
static GeZis:number[]=[];
static BanMove:number[]=[65];
static GeZi:number;  
messageLevel: number=1
messageType: String="GeZiManager"
static Ban:number[]=[];
static bule:number[]=[];
static red:number[]=[0];    

static YuanGong:GeZi[]=[]
static trees:number[]=[]; 
static DL:number[][]=[[]]; 
static Qi:number=0;
static HP:number=0;
static free:number=0;
static PCP:character=null
static face:number=0;
static  WD:number[] =[];
static label: Slabel[]=[];
static rock:number[]=[];
static Bu:number[]=[];
static WindSon:ComponentBase[]=[];
static KillSon:ComponentBase[]=[];
static ShopSon:ComponentBase[]=[];
static magic:ComponentBase[]=[];
static P1:character=null;
static P2:character=null;
static P3:character=null;
static P4:character=null;
static P5:character=null;
static P6:character=null;
static sideUI:sideUI[]=[];
static blueP:character[]=[];
static redP:character[]=[];



start() {
    function findNodeInScene(node: cc.Node, targetName: string): cc.Node | null {
        if (node.name === targetName) {
            return node;
        }
        for (let i = 0; i < node.childrenCount; i++) {
            const child = node.children[i];
            const result = findNodeInScene(child, targetName);
            if (result) {
                return result;
            }
        }
        
        return null;
     }
     let rootNode = cc.director.getScene().getChildByName("Canvas");
     
     const targetNode = findNodeInScene(rootNode, "UIManager"); // 假设要查找的节点名为"TargetNodeName"
     if (targetNode) {
         // 找到了目标节点
         console.log("找到了目标节点");
     } else {
         // 没有找到目标节点
         console.log("没有找到目标节点");
     }
     
     targetNode.getComponent(UIManager).addReceive(this)
     
     
     

}


static changeChoose(){
switch(state.ST){
  case 0  :for(let mannger of this.YuanGong){
        
        
        let a=""
        
     
        let message=new Message(a,[65],1)
        mannger.ReceiveMessage(message)
     
if(turn.turn%2==0){GeZiManager.redBan();}else {GeZiManager.blueBan()}

       message=new Message(a,[GeZiManager.GeZi],2)
        mannger.ReceiveMessage(message)
    }
break;






}}









static redBan(){


    for(let mannger of this.YuanGong){
        
        
        let a=""
        
     
   
       let message=new Message(a,GeZiManager.bule,"redBan")
        mannger.ReceiveMessage(message)
        let message2=new Message(a,this.trees,5)
        mannger.ReceiveMessage(message2);

    }




}









static Gtree(){ 
    for(let mannger of this.YuanGong){
        
        
        let a=""
        let message2=new Message(a,this.trees,5)
        mannger.ReceiveMessage(message2);}


    }

static blueBan(){
    for(let mannger of this.YuanGong){
        
        
        let a=""
        
     
     
       let message=new Message(a,GeZiManager.red,"blueBan")
        mannger.ReceiveMessage(message)
       
     
    }
}



static qing(){

    for(let mannger of this.YuanGong){
        
        
        let a=" "
        
     
     
       let message=new Message(a,[65],1)
        mannger.ReceiveMessage(message)



}


















}
static shanchu(arr:any,target:any){

    for (let i: number = arr.length - 1; i >= 0; i--) {
      if (arr[i] == target) {
        arr.splice(i, 1);  // 使用splice方法删除匹配的元素
      }
    }




}


static getWD(face:number){


switch (face) {
    case 2:
        
    
    for(let WD of GeZiManager.WD){
        let X
        let Y
        if(WD%8==0){X=8}else{
       X=WD%8;}
       Y=Math.ceil(WD/8)
for(let manager of GeZiManager.onX(X)){
if(manager<WD){GeZiManager.Ban.push(manager)}

} }
 
        break;
    case 4:
        
    
        for(let WD of GeZiManager.WD){
            let X
            let Y
            if(WD%8==0){X=8}else{
           X=WD%8;}
           Y=Math.ceil(WD/8)
    for(let manager of GeZiManager.onY(Y)){
    if(manager<WD){GeZiManager.Ban.push(manager)}
    
    } }
     
            break;
    case 6:
        
    
            for(let WD of GeZiManager.WD){
                let X
                let Y
                if(WD%8==0){X=8}else{
               X=WD%8;}
               Y=Math.ceil(WD/8)
               for(let manager of GeZiManager.onY(Y)){
                if(manager>WD){GeZiManager.Ban.push(manager)}
        
        } }
         
                break;
    case 8:
        
    
                for(let WD of GeZiManager.WD){
                    let X
                    let Y
                    if(WD%8==0){X=8}else{
                   X=WD%8;}
                   Y=Math.ceil(WD/8)
            for(let manager of GeZiManager.onX(X)){
            if(manager>WD){GeZiManager.Ban.push(manager)}
            
            } }
             
                    break;
    default:
        break;
}





}

  



static onY(Y:number){
let YS:number[]=[];
for(let mannger of this.BanMove){
if(Y==Math.ceil(mannger/8)){


YS.push(mannger);

}

}

return YS;
}




static onX(X:number){
    let XS:number[]=[];
    for(let mannger of this.BanMove){
    if(mannger==65){}else{
        if(X==8){if(mannger%8==0){XS.push(mannger);}}else{if(X==mannger%8){XS.push(mannger);}}
   
    }}
    return XS;
    }
    
  
    
static DLBZ(ZB:number){
    let a=GeZiManager.DL
    for (let i = 0; i <a.length; i++) {
        if (a[i][0] == ZB) {
       
     
            MessageCenter.MakeSHMessage("AM",[ZB],a[i][1],null,"wuli") ;
            DESManager.Des(ZB);
            GeZiManager.shanchu(GeZiManager.DL,a[i])
      
        }
      }

}

static DLBX(ZB:number){
    let a=GeZiManager.DL
    for (let i = 0; i <a.length; i++) {
        if (a[i][0] == ZB) {
       
            a[i][1]-=1;
       if(a[i][1]==0){
            DESManager.Des(ZB);
            GeZiManager.shanchu(GeZiManager.DL,a[i])
      
        }}
      }

}








 static line(pos:number,ptr:number,dir:number,Enemy:number[]):number[]{
        let land:number[][]=[[57,58,59,60,61,62,63,64],[49,50,51,52,53,54,55,56],[41,42,43,44,45,46,47,48],[33,34,35,36,37,38,39,40],[25,26,27,28,29,30,31,32],[17,18,19,20,21,22,23,24],[9,10,11,12,13,14,15,16],[1,2,3,4,5,6,7,8]];
   
        let row:number,col:number;
        let res:number[]=[];
        row=-1;
        col=-1;
        if(ptr<=0){
            console.log("输入穿透不合法");
            return res;
        }
        if(pos>=57&&pos<=64){
            row=0;
            col=pos-57;
        }
        else if(pos>=49&&pos<=56){
            row=1;
            col=pos-49;
        }
        else if(pos>=41&&pos<=48){
            row=2;
            col=pos-41;
        }
        else if(pos>=33&&pos<=40){
            row=3;
            col=pos-33;
        }
        else if(pos>=25&&pos<=32){
            row=4;
            col=pos-25;
        }
        else if(pos>=17&&pos<=24){
            row=5;
            col=pos-17;
        }
        else if(pos>=9&&pos<=16){
            row=6;
            col=pos-9;
        }
        else if(pos>=1&&pos<=8){
            row=7;
            col=pos-1;
        }
        else{
            console.log("输入位置不合法");
            return res;
        }
        let count:number=0;
        if(dir==6){
            for(let i=col+1;i<8;i++)
            {
                for(let num of Enemy)
                {
                    if(count==ptr) return res;
                    if(num==land[row][i])
                    {
                        res[count]=num;
                        count+=1;
                    }
                }
            }
            return res;
        }
        else if(dir==9)
        {
            let i=col+1;
            let j=row-1;
            while(i<8&&j>=0)
            {
                for(let num of Enemy)
                {
                    if(count==ptr) return res;
                    if(num==land[j][i])
                    {
                        res[count]=num;
                        count+=1;
                    }
                }
                i+=1;
                j-=1;
            }
            return res;
        }
        else if(dir==8)
        {
            let i=row-1;
            while(i>=0)
            {
                for(let num of Enemy)
                {
                    if(count==ptr) return res;
                    if(num==land[i][col])
                    {
                        res[count]=num;
                        count+=1;
                    }
                }
                i-=1;
            }
            return res;
        }
        else if(dir==7)
        {
            let i=col-1;
            let j=row-1;
            while(i>=0&&j>=0)
            {
                for(let num of Enemy)
                {
                    if(count==ptr) return res;
                    if(num==land[j][i])
                    {
                        res[count]=num;
                        count+=1;
                    }
                }
                i-=1;
                j-=1;
            }
            return res;
        }
        else if(dir==4)
        {
            for(let i=col-1;i>=0;i--)
            {
                for(let num of Enemy)
                {
                    if(count==ptr) return res;
                    if(num==land[row][i])
                    {
                        res[count]=num;
                        count+=1;
                    }
                }
            }
            return res;
        }
        else if(dir==1)
        {
            let i=col-1;
            let j=row+1;
            while(i>=0&&j<6)
            {
                for(let num of Enemy)
                {
                    if(count==ptr) return res;
                    if(num==land[j][i])
                    {
                        res[count]=num;
                        count+=1;
                    }
                }
                i-=1;
                j+=1;
            }
            return res;
        }
        else if(dir==2)
        {
            let i=row+1;
            while(i<8)
            {
                for(let num of Enemy)
                {
                    if(count==ptr) return res;
                    if(num==land[i][col])
                    {
                        res[count]=num;
                        count+=1;
                    }
                }
                i+=1;
            }
            return res;
        }
        else if(dir==3)
        {
            let i=col+1;
            let j=row+1;
            while(i<8&&j<8)
            {
                for(let num of Enemy)
                {
                    if(count==ptr) return res;
                    if(num==land[j][i])
                    {
                        res[count]=num;
                        count+=1;
                    }
                }
                i+=1;
                j+=1;
            }
            return res;
        }
       
     else if(dir==5)
        {
           
                for(let num of Enemy)
                {
                    if(count==ptr) return res;
                    if(num==pos)
                    {
                        res[count]=num;
                      
                    }
                }
                
            
            return res;
        }
        else
        {
            console.log("输入方向不合法");
            return res;
        }
    }
    
    















}
