import ComponentBase from "./ComponentBase";
import { Message } from "./Message";
import MessageCenter from "./MessageCenter";

const {ccclass, property} = cc._decorator;

@ccclass
export default class ManagerBase extends  ComponentBase {

 YuanGong:ComponentBase[];
messageType:String;
messageLevel:number=0;
 
  


GetType(){
    return " "
}

addReceive(xin:ComponentBase){

    this.YuanGong.push(xin);
    
}




ReceiveMessage(message: Message){

    if(message.Type==this.messageType) {this.DO}
   } 

DO(message: Message){}

}




