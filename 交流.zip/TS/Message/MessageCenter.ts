
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import realThing from "../realThing";
import ComponentBase from "./ComponentBase";
import { Message } from "./Message";
import UIManager from "./UIManager";
import { SHMessage } from "./xinxi/SHMessage";

const {ccclass, property} = cc._decorator;

@ccclass
export default class MessageCenter  {
    static Managers:ComponentBase[]=[];



static addReceive(xin:ComponentBase){

    MessageCenter.Managers.push(xin);
}


  
    
static SendMessage(message:Message){
for(let mannger of this.Managers){
    mannger.ReceiveMessage(message)

}

}


static MakeMessage(Type:string,Command:any,Content:any){

let message=new Message(Type,Command,Content)
this.SendMessage(message);

}
static MakeSHMessage(Type:string,Command:any,Content:any,from:realThing,SHtype:string){

    let message=new SHMessage(Type,Command,Content,from,SHtype)
    this.SendMessage(message);

    }
}
