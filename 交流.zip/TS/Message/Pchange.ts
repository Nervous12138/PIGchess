// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import player from "../player";
import state from "../state";
import turn from "../turn";
import GeZiManager from "./GeZiManager";
import MessageCenter from "./MessageCenter";

const {ccclass, property} = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

  p1(){

player.Pturn=1
 
state.Pchange();

}
 p2(){

    player.Pturn=2
   
   
    state.Pchange();

}

 p3(){

        player.Pturn=3
        state.Pchange();

    }

p4(){

            player.Pturn=4
            state.Pchange() 
        }
p5(){

player.Pturn=5
state.Pchange() 

}

 p6(){
                    player.Pturn=6
                    state.Pchange()  
             }




              start() {
                   
             
                this.scheduleOnce(this.executeImmediately,0);
            }
            executeImmediately() {
              this.p1();
            }
                   
          
   k(){state.statechange();}       
          
          
          
          
          
          }

                
