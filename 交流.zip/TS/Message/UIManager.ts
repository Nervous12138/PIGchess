import player from "../player";
import state from "../state";
import turn from "../turn";
import ComponentBase from "./ComponentBase";
import GeZiManager from "./GeZiManager";
import ManagerBase from "./ManagerBase";
import { Message } from "./Message";
import MessageCenter from "./MessageCenter";
import BUIManager from "./xinxi/BUIManager";




const {ccclass, property} = cc._decorator;

@ccclass
export default class UIManager extends ManagerBase{

   
    UIState:number=0;
YuanGong: ComponentBase[] = [];
    messageType="UIManager"

 
    GUI: cc.Node;
    
    
 



public changeUI(state:number){
let BUI=this.node.getChildByName("BUIManager")
let CUI=this.node.getChildByName("CUIManager")
let SUI1=this.node.getChildByName("shopUI")
let MUI= this.node.getChildByName("magicUI")
let a=[["UIManager","GUIManager"]];
let WF=this.node.getChildByName("WFace")
this.UIState=state;
switch (this. UIState) {
    
            
   
    case -1:BUI.getChildByName("BUI").active=false; CUI.getChildByName("yesno").active=false; this.GUI.active=true;SUI1.active=false;MUI.active=false;WF.active=false;
        
        break;
    
    
    case 0:BUI.getChildByName("BUI").active=false; CUI.getChildByName("yesno").active=false ;this.GUI.active=false;SUI1.active=false;MUI.active=false;WF.active=false;
        
        break;
        case 1:BUI.getChildByName("BUI").active=true;CUI.getChildByName("yesno").active=false;this.GUI.active=false;SUI1.active=false;MUI.active=false;WF.active=false;
        
        
        break;
        
        case 2:BUI.getChildByName("BUI").active=false;CUI.getChildByName("yesno").active=true;this.GUI.active=true;SUI1.active=false;MUI.active=false;WF.active=false;
        
        break;
        case 2.5:BUI.getChildByName("BUI").active=false;CUI.getChildByName("yesno").active=true;this.GUI.active=false;SUI1.active=false;MUI.active=false;WF.active=true;
        
        break;
        case 3:BUI.getChildByName("BUI").active=false;CUI.getChildByName("yesno").active=false;this.GUI.active=false;SUI1.active=true;MUI.active=false;WF.active=false;
        
        break;

        case 4:BUI.getChildByName("BUI").active=false;CUI.getChildByName("yesno").active=false;this.GUI.active=false;SUI1.active=false;MUI.active=true;WF.active=false;
        
        break;
        
        
        
        case 5:BUI.getChildByName("BUI").active=false;CUI.getChildByName("yesno").active=false;this.GUI.active=false;SUI1.active=false;MUI.active=false;WF.active=true;
        
        
        break;
        
        default:BUI.getChildByName("BUI").active=false;
        break;
}
}









start(){
   MessageCenter.addReceive(this);
   function findNodeInScene(node: cc.Node, targetName: string): cc.Node | null {
    if (node.name === targetName) {
        return node;
    }
    for (let i = 0; i < node.childrenCount; i++) {
        const child = node.children[i];
        const result = findNodeInScene(child, targetName);
        if (result) {
            return result;
        }
    }
    
    return null;
 }
 let rootNode = cc.director.getScene().getChildByName("Canvas");
 
 const targetNode = findNodeInScene(rootNode, "GUIManager"); // 假设要查找的节点名为"TargetNodeName"
 if (targetNode) {
     // 找到了目标节点
     console.log("找到了目标节点");
 } else {
     // 没有找到目标节点
     console.log("没有找到目标节点");
 }
    
   this.GUI=targetNode; 




             this.addReceive(this.node.getChildByName("BUIManager").getComponent(BUIManager))
      
    
         this.changeUI(-1);





 }















ReceiveMessage(message: Message){
   
 if(message.Type=="UIManager")
   
   this.DO(message)
}


DO(message: Message){
    let BUI=this.node.getChildByName("BUIManager")
let CUI=this.node.getChildByName("CUIManager")
    if(message.Command=="change"){
        this.changeUI(message.Content)
    
    
    
    
    }}
   






















}
























