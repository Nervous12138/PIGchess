// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import shopM from "../../game/ShopM";
import turn from "../../turn";
import GeZiManager from "../GeZiManager";
import ManagerBase from "../ManagerBase";
import { Message } from "../Message";
import MessageCenter from "../MessageCenter";

const {ccclass, property} = cc._decorator;

@ccclass
export default class BUIManager extends ManagerBase {
  
   
    SUI:cc.Node=null;
     A1:cc.Node=null;
     A2:cc.Node=null;
     A3:cc.Node=null;
     A4:cc.Node=null;
     A5:cc.Node=null;
     leveUP:cc.Node=null;
     changL:cc.Node=null;
  start(){
    
      
  MessageCenter.addReceive(this)
 this.SUI= cc.find("Canvas/UIManager/shopUI/1L/A1")
 this.A1= cc.find("Canvas/UIManager/shopUI/1L/A1")
 this.A2= cc.find("Canvas/UIManager/shopUI/1L/A2")
 this.A3= cc.find("Canvas/UIManager/shopUI/1L/A3")
 this.A4= cc.find("Canvas/UIManager/shopUI/2L/XianJing")
 this.A5= cc.find("Canvas/UIManager/shopUI/2L/BCD")
 this.leveUP= cc.find("Canvas/UIManager/shopUI/3L/Leve")
 this.changL= cc.find("Canvas/UIManager/shopUI/3L/changL")
}
  
  
  
  
  
  
  
  ReceiveMessage(message: Message){

  if(message.Type=="BUI"){
  switch(message.Content){
  case"Ban":this.banUI(message.Command);
  break;
  case"Use":this.useUI(message.Command);
  break;
  case"change0.5":this.changeUI(message.Command,0.5);
  break;
  case"change1":this.changeUI(message.Command,1);
  break;
  }
  
  
  }    
  
  
  
  
  
  }
  
  
changeUI(number:number[],st:number){
    let  BUI=this.node.getChildByName("BUI")      
    let  BaseChoose=BUI.getChildByName("BaseChoose") 
    let  turnB=BUI.getChildByName("turnB")
   
    for(let n of number){
        switch (n) {
            case 0:turnB.getChildByName("turn4").getComponent(cc.Button).interactable=true;turnB.getChildByName("turn6").getComponent(cc.Button).interactable=true;
                break;
                case 1:BaseChoose.getChildByName("qi").getComponent(cc.Button).interactable=true;
                break;
                case 2:switch (st) {
                    case 0.5:MessageCenter.MakeMessage("AM",turn.turn,"getC");let n=GeZiManager.PCP.HP+GeZiManager.PCP.qi-6;         
                    if(n>=0&&GeZiManager.PCP.qi>0){BaseChoose.getChildByName("move").getComponent(cc.Button).interactable=true;
                   }else{BaseChoose.getChildByName("move").getComponent(cc.Button).interactable=false;} 
                   BaseChoose.getChildByName("move").getChildByName("Background").getChildByName("Label").getComponent(cc.Label).string="推石头";
                        
                        break;
                
                    default:BaseChoose.getChildByName("move").getChildByName("Background").getChildByName("Label").getComponent(cc.Label).string="移动";
                        break;
                }
               
               
               
               
               
             
        }
        
        
            }



} 
  
  
useUI(number:number[]){
   
    let  BUI=this.node.getChildByName("BUI")      
   let  BaseChoose=BUI.getChildByName("BaseChoose") 
   let  turnB=BUI.getChildByName("turnB")
   for(let n of number){
    switch (n) {
        case 0:turnB.getChildByName("turn4").getComponent(cc.Button).interactable=true;turnB.getChildByName("turn6").getComponent(cc.Button).interactable=true;
            break;
            case 1:BaseChoose.getChildByName("qi").getComponent(cc.Button).interactable=true;
            break;
            case 2:BaseChoose.getChildByName("move").getComponent(cc.Button).interactable=true;
            break;
            case 3:BaseChoose.getChildByName("attack").getComponent(cc.Button).interactable=true;
            break;
            case 4:BaseChoose.getChildByName("magic").getComponent(cc.Button).interactable=true;
            break;
            case 5:BaseChoose.getChildByName("shop").getComponent(cc.Button).interactable=true;
            break;
            case 51:this.A1.getComponent(cc.Button).interactable=true;
            break;
            case 52:this.A2.getComponent(cc.Button).interactable=true;
            break;
            case 53:this.A3.getComponent(cc.Button).interactable=true;
            break;
            case 54:this.A4.getComponent(cc.Button).interactable=true;
            break;
            case 55:this.A5.getComponent(cc.Button).interactable=true;
            break;
            case 56:this.leveUP.getComponent(cc.Button).interactable=true;
            break;
            case 57:this.changL.getComponent(cc.Button).interactable=true;
            break;
           
        default:
            break;
    }
    
    
        }}
  
  
  
  
  
  
  
  
  banUI(number:number[]){
  
  let  BUI=this.node.getChildByName("BUI")      
 let  BaseChoose=BUI.getChildByName("BaseChoose")
 let  turnB=BUI.getChildByName("turnB")
 for(let n of number){
  switch (n) {
      case 0:turnB.getChildByName("turn4").getComponent(cc.Button).interactable=false;turnB.getChildByName("turn6").getComponent(cc.Button).interactable=false
          break;
          case 1:BaseChoose.getChildByName("qi").getComponent(cc.Button).interactable=false;
          break;
          case 2:BaseChoose.getChildByName("move").getComponent(cc.Button).interactable=false;
          break;
          case 3:BaseChoose.getChildByName("attack").getComponent(cc.Button).interactable=false;
          break;
          case 4:BaseChoose.getChildByName("magic").getComponent(cc.Button).interactable=false;
          break;
          case 5:BaseChoose.getChildByName("shop").getComponent(cc.Button).interactable=false;
          break;
          case 5:BaseChoose.getChildByName("shop").getComponent(cc.Button).interactable=false;
          break;
          case 51:this.A1.getComponent(cc.Button).interactable=false;
          break;
          case 52:this.A2.getComponent(cc.Button).interactable=false;
          break;
          case 53:this.A3.getComponent(cc.Button).interactable=false;
          break;
          case 54:this.A4.getComponent(cc.Button).interactable=false;
          break;
          case 55:this.A5.getComponent(cc.Button).interactable=false;
          break;
          case 56:this.leveUP.getComponent(cc.Button).interactable=false;
          break;
          case 57:this.changL.getComponent(cc.Button).interactable=false;
          break;
      default:
          break;
  }
}
  
      }
}
