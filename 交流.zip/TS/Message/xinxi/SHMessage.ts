// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import realThing from "../../realThing";
import { Message } from "../Message";

const {ccclass, property} = cc._decorator;

@ccclass
export  class SHMessage extends Message {

from:realThing;
SHtype:any;







    constructor(Type:string,Command:any,Content:any,from:realThing,SHtype:string,  ){
    super(Type,Command,Content);
       this.SHtype=SHtype;
        this.from=from;
        }
   

    }

 

