// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import ComponentBase from "../Message/ComponentBase";
import GeZiManager from "../Message/GeZiManager";
import MessageCenter from "../Message/MessageCenter";
import shops from "../equipment/shops";
import weapon from "../equipment/weapon/weapon";
import shopM from "../game/ShopM";
import state from "../state";
import turn from "../turn";
import yesno from "./yesno";

const {ccclass, property} = cc._decorator;

@ccclass
export default class BUI extends ComponentBase {

    SUI:cc.Node=null;
    A1:cc.Node=null;
    A2:cc.Node=null;
    A3:cc.Node=null;
    A4:cc.Node=null;
    A5:cc.Node=null;
    leveUP:cc.Node=null;
    changL:cc.Node=null;
yes:cc.Node;
i:number=1;
    start(): void {
    function findNodeInScene(node: cc.Node, targetName: string): cc.Node | null {
        if (node.name === targetName) {
            return node;
        }
        for (let i = 0; i < node.childrenCount; i++) {
            const child = node.children[i];
            const result = findNodeInScene(child, targetName);
            if (result) {
                return result;
            }
        }
        
        return null;
     }
     let rootNode = cc.director.getScene().getChildByName("Canvas");
     
    this.yes = findNodeInScene(rootNode, "yes");
    this.SUI= cc.find("Canvas/UIManager/shopUI/1L/A1")
 this.A1= cc.find("Canvas/UIManager/shopUI/1L/A1")
 this.A2= cc.find("Canvas/UIManager/shopUI/1L/A2")
 this.A3= cc.find("Canvas/UIManager/shopUI/1L/A3")
 this.A4= cc.find("Canvas/UIManager/shopUI/2L/XianJing")
 this.A5= cc.find("Canvas/UIManager/shopUI/2L/BCD")
 this.leveUP= cc.find("Canvas/UIManager/shopUI/3L/Leve")
 this.changL= cc.find("Canvas/UIManager/shopUI/3L/changL")
}



ST(){
    let a=[]
    MessageCenter.MakeMessage("AM",turn.turn,"getC")
    this.A1.getChildByName("xLabel").getComponent(cc.Label).string="售价为"+shopM.A1n[0]+"  剩"+shopM.A1n[1]+"个"
    this.A2.getChildByName("xLabel").getComponent(cc.Label).string="售价为"+shopM.A2n[0]+"  剩"+shopM.A2n[1]+"个"
    this.A3.getChildByName("xLabel").getComponent(cc.Label).string="售价为"+shopM.A3n[0]+"  剩"+shopM.A3n[1]+"个"
    this.A4.getChildByName("xLabel").getComponent(cc.Label).string="售价为"+shopM.A4n[0]+"  剩"+shopM.A4n[1]+"个"
   
   
    switch (GeZiManager.PCP.weapon.getComponent(weapon).TheNumber){
        case "A000":a.push(56);a.push(57);  break;
        case "A110": if(GeZiManager.PCP.qi<2+GeZiManager.free){a.push(56)}
            
        
        
        
                
                break;
         case "A130": if(GeZiManager.PCP.qi<4+GeZiManager.free){a.push(56)}
            
            
         case "A210": if(GeZiManager.PCP.qi<3+GeZiManager.free){a.push(56)}
       
         break;
        case "A232":  if(GeZiManager.PCP.qi<4+GeZiManager.free){a.push(56)}
            break;
        case "A231":  if(GeZiManager.PCP.qi<4+GeZiManager.free){a.push(56)}
        break;
            
            
        case "A310":  if(GeZiManager.PCP.qi<2+GeZiManager.free){a.push(56)}
        break;
        ;   
            
            
            
            
                default:
                break;






    }
    
    if((GeZiManager.PCP.qi<=shopM.A1n[0]+GeZiManager.free)&&shopM.A1n[1]>0){a.push(51)
   }
   if((GeZiManager.PCP.qi<=shopM.A2n[0]+GeZiManager.free)&&shopM.A2n[1]>0){a.push(52)
   }
   if((GeZiManager.PCP.qi<=shopM.A3n[0]+GeZiManager.free)&&shopM.A3n[1]>0){a.push(53)
   }
   if((GeZiManager.PCP.qi<=shopM.A4n[0]+GeZiManager.free)&&shopM.A4n[1]>0){a.push(54)
   }
   
   
   MessageCenter.MakeMessage("BUI",[51,52,53,54,55,56,57],"Use")
   
   MessageCenter.MakeMessage("BUI",a,"Ban")
}






    qi(){

MessageCenter.MakeMessage("AM",turn.turn,"Qi+");
    }
walk(){

MessageCenter.MakeMessage("AM",turn.turn,"walk");
GeZiManager.Bu.push(2);
}
attack(){

    MessageCenter.MakeMessage("AM",turn.turn,"attack");

}
magic(){  MessageCenter.MakeMessage("UIManager","change",4);}
shop(){


    MessageCenter.MakeMessage("UIManager","change",3);
this.ST();
}
PASS(){
   
MessageCenter.MakeMessage("AM",turn.turn,"getC");  
 if( GeZiManager.PCP.LST==-1){GeZiManager.PCP.node.getComponent(cc.Sprite).spriteFrame=GeZiManager.PCP.Atlas.getSpriteFrame("gost")
 GeZiManager.PCP.node.width=175; GeZiManager.PCP.node.height=200;
 GeZiManager.PCP.node.opacity=100;
}
    turn.turn++;
    turn.turnpass();


MessageCenter.MakeMessage("AM",turn.turn,"ST");
MessageCenter.MakeMessage("UIManager","change",0);
state.ST=1;
}


turn4(){

MessageCenter.MakeMessage("AM",turn.turn,"turn4");
MessageCenter.MakeMessage("AM",turn.turn,"ST");
GeZiManager.Bu.push(0.4);
}



turn6(){

    MessageCenter.MakeMessage("AM",turn.turn,"turn6");
    MessageCenter.MakeMessage("AM",turn.turn,"ST");

    
    GeZiManager.Bu.push(0.6);
    }


shopX(){
    MessageCenter.MakeMessage("UIManager","change",1);



}


dA1(){


if(this.qic(shopM.A1n[0]+GeZiManager.free)&&shopM.A1n[1]>0){
    shopM.A1n[1]-=1;
let A1=this.node.getComponent(shops).A110

MessageCenter.MakeMessage("AM",A1,"changE1")
MessageCenter.MakeMessage("UIManager","change",1);
MessageCenter.MakeMessage("BUI",[3],"Ban");
}
}


dA2(){


    if(this.qic(shopM.A2n[0]+GeZiManager.free)&&shopM.A2n[1]>0){
        shopM.A2n[1]-=1;

    let A2=this.node.getComponent(shops).A210
    
    MessageCenter.MakeMessage("AM",A2,"changE1")
    MessageCenter.MakeMessage("UIManager","change",1);
MessageCenter.MakeMessage("BUI",[3],"Ban");
    }

}
    dA3(){

        if(this.qic(shopM.A3n[0]+GeZiManager.free)&&shopM.A3n[1]>0){
            shopM.A3n[1]-=1;


        let A3=this.node.getComponent(shops).A310
        
        MessageCenter.MakeMessage("AM",A3,"changE1")
        MessageCenter.MakeMessage("UIManager","change",1);
MessageCenter.MakeMessage("BUI",[3],"Ban");
        }
    }
dilei(){ if(this.qic(1+GeZiManager.free)){


    MessageCenter.MakeMessage("AM",turn.turn,"getZB")


   state.ST=2;
    MessageCenter.MakeMessage("UIManager","change",-1);
for(let manager of GeZiManager.YuanGong){

manager.getFar(4);
if(GeZiManager.BanMove.includes(manager.ZB)||GeZiManager.DL[0].includes(manager.ZB)){
    manager.red();
}


}

MessageCenter.MakeMessage("BUI",[3],"Ban");
}


}
qic(qic:number){
    console.log(qic)
    MessageCenter.MakeMessage("AM",turn.turn,"getQi")
    MessageCenter.MakeMessage("AM",turn.turn,"getZB")
if(GeZiManager.Qi>=qic){    MessageCenter.MakeSHMessage("AM",[GeZiManager.GeZi],qic,null,"Qi-");

GeZiManager.free=0;
return true}else{
    
   for(let ma of GeZiManager.label){
    ma.Fqic();
   }
    
    
    return false}


 } 


dleveUP(){
    MessageCenter.MakeMessage("AM",turn.turn,"getC")
let A1;
    switch (GeZiManager.PCP.weapon.getComponent(weapon).TheNumber) {
    
    
    case "A110": if(this.qic(2+GeZiManager.free)){A1=this.node.getComponent(shops).A130
    MessageCenter.MakeMessage("AM",A1,"changE1")}else{


    }
        
        break;
 case "A130": A1=this.node.getComponent(shops).A150
        MessageCenter.MakeMessage("AM",A1,"changE1")
        break;
    
    
 case "A210": switch(this.i){
    
    
    case 1:if(this.qic(3+GeZiManager.free)){A1=this.node.getComponent(shops).A231;}
     break;

    case 2:if(this.qic(3+GeZiManager.free)){A1=this.node.getComponent(shops).A232}   
    break;
 }
 MessageCenter.MakeMessage("AM",A1,"changE1")
 break;
case "A232": if(this.qic(3+GeZiManager.free)){A1=this.node.getComponent(shops).A252
        MessageCenter.MakeMessage("AM",A1,"changE1")}
    break;
case "A231": if(this.qic(3+GeZiManager.free)){A1=this.node.getComponent(shops).A251
MessageCenter.MakeMessage("AM",A1,"changE1")}
break;
    
    
case "A310": A1=this.node.getComponent(shops).A130
MessageCenter.MakeMessage("AM",A1,"changE1")
break;
;   
    
    
    
    
        default:
        break;
}

MessageCenter.MakeMessage("UIManager","change",1);
MessageCenter.MakeMessage("BUI",[3],"Ban");






}



changI(){
    
    switch (this.i) {
        case 1:this.i=2
            
            break;
    case 2:this.i=1
        default:
            break;
    }
    
  }


}
