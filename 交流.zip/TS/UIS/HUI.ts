// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import ComponentBase from "../Message/ComponentBase";
import { Message } from "../Message/Message";
import { SHMessage } from "../Message/xinxi/SHMessage";
import character from "../character";
import HP from "./heart";
import heart from "./heart";

const {ccclass, property} = cc._decorator;

@ccclass
export default class HUI extends ComponentBase {

MaxHP:number=5;
HP:number=5;

@property(cc.SpriteAtlas)
Atlas:cc.SpriteAtlas=null;

@property(cc.Prefab)
heart:cc.Prefab=null;
@property(cc.Prefab)
Pturn:cc.Prefab=null;
@property(cc.Prefab)
Qi:cc.Prefab=null;

hearts:HP[]=[];



 onLoad(){
   


}








 start(){
    this.node.parent.getComponent(character).UI.push(this)
    this.node.parent.getComponent(character).MaxHP=this.MaxHP;

   let Pturn=cc.instantiate(this.Pturn)
    Pturn.setParent(this.node)

for(let i=1;i<=this.MaxHP;i++){
   let HP=cc.instantiate(this.heart)
   HP.setParent(this.node)
 HP.getComponent(heart).DB=i;

}













switch (this.node.parent.getComponent(character).Pturn) {
    case 1:this.node.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("bule")
        Pturn.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("1");Pturn.anchorY=0.55;
        break;
     case 2:this.node.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("red")
        Pturn.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("2");Pturn.anchorY=0.4;
        break;
        case 3:this.node.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("bule")
        Pturn.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("3");this.node.getComponent(cc.Layout).paddingLeft=18;Pturn.anchorY=0.53;
        break;
        case 4:this.node.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("red");Pturn.anchorY=0.47;
        Pturn.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("4")
        break;
        case 5:this.node.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("bule");Pturn.anchorX=0.52;
        Pturn.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("5")
        break;
        case 6:this.node.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("red");Pturn.anchorY=0.53;
        Pturn.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("6")
        break;

    
    

    default:
        break;
}

let Qi=cc.instantiate(this.Qi);
Qi.setParent(this.node.parent);

this.setQi();











}



setQi(){
if(this.node.parent.getComponent(character).qi>=15)
{this.node.parent.getChildByName("qi").getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("Qi15+");this.node.parent.getChildByName("qi").scaleY=3;this.node.parent.getChildByName("qi").scaleX=1.95;this.node.parent.getChildByName("qi").anchorX=0.63;this.node.parent.getChildByName("qi").anchorY=0.53;
}else if(this.node.parent.getComponent(character).qi>=10)
{this.node.parent.getChildByName("qi").getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("Qi10+");this.node.parent.getChildByName("qi").scaleY=2.5;this.node.parent.getChildByName("qi").scaleX=1.89;this.node.parent.getChildByName("qi").anchorX=0.64;this.node.parent.getChildByName("qi").anchorY=0.48;
}else if(this.node.parent.getComponent(character).qi>5)
{this.node.parent.getChildByName("qi").getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("Qi5+");this.node.parent.getChildByName("qi").scaleY=2;this.node.parent.getChildByName("qi").scaleX=1.9;this.node.parent.getChildByName("qi").anchorX=0.65;
}else switch (this.node.parent.getComponent(character).qi) {
        case 5:this.node.parent.getChildByName("qi").getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("Qi5");
        break;
        case 4:this.node.parent.getChildByName("qi").getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("Qi4");
        break;
        case 3:this.node.parent.getChildByName("qi").getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("Qi3");
        break;
        case 2:this.node.parent.getChildByName("qi").getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("Qi2");
        break;
        case 1:this.node.parent.getChildByName("qi").getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("Qi1");
        break;

    default:this.node.parent.getChildByName("qi").getComponent(cc.Sprite).spriteFrame=null
        break;
}





}




setHP(){
    this.MaxHP=this.node.parent.getComponent(character).MaxHP;
    this.HP=this.node.parent.getComponent(character).HP;








    let n=this.MaxHP-this.HP;
for(let mannger of this.hearts){
    mannger.to1();
    
}

 for(let i=this.MaxHP;i>this.HP;i--){
for(let mannger of this.hearts){
  if(mannger.DB==i){mannger.to0();}

}



}



}










ReceiveMessage(message: Message) {
    if(message instanceof SHMessage){ switch (message.SHtype){
        case "Qi+":this.setQi();
        
        break;
        case "Qi-":this.setQi();
        
        break;
        case "Qi=":this.setQi();
        
        break;
        case "Qi":this.setQi();
        
        break;













    }}else{




















    switch (message.Content) {
    case "Qi+":this.setQi();
        
        break;

    default:
        break;
}
}


}








}
