// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import AnimalManager from "../Message/AnimalManager";
import ComponentBase from "../Message/ComponentBase";
import GeZiManager from "../Message/GeZiManager";
import { Message } from "../Message/Message";
import MessageCenter from "../Message/MessageCenter";
import { SHMessage } from "../Message/xinxi/SHMessage";
import state from "../state";
import turn from "../turn";

const {ccclass, property} = cc._decorator;

@ccclass
export default class MUI extends ComponentBase {

   

    start () {

    }

 qic(qic:number){
    MessageCenter.MakeMessage("AM",turn.turn,"getQi")
    MessageCenter.MakeMessage("AM",turn.turn,"getZB")
if(GeZiManager.Qi>=qic){    MessageCenter.MakeSHMessage("AM",[GeZiManager.GeZi],qic,null,"Qi-");
MessageCenter.MakeMessage("AM",turn.turn,"getQi")
console.log(GeZiManager.Qi)
GeZiManager.free=0;
return true}else{return false}


 } 


back(){
    MessageCenter.MakeMessage("UIManager","change",1);

    
}



fireball(){

if(this.qic(2-GeZiManager.free)){

   
        MessageCenter.MakeMessage("UIManager","change",-1);
        MessageCenter.MakeMessage("UIManager","change",-1);
        for(let manager of GeZiManager.YuanGong){
let a=new Message("",[65],-1)
            manager.ReceiveMessage(a)    
}
MessageCenter.MakeMessage("AM",turn.turn,"getZB")

for(let manager of GeZiManager.YuanGong){
  manager.getFar(5);

state.ST=10;



}}}


falsh(){
    if(this.qic(3-GeZiManager.free)){

        MessageCenter.MakeMessage("AM",turn.turn,"getC");
    
        let a  = GeZiManager.PCP.findGe(GeZiManager.PCP.faceTo,2)
     if(GeZiManager.BanMove.includes(a)){}else{
     GeZiManager.PCP.To(a);}
     




}}




cure(){

    if(this.qic(3-GeZiManager.free)){
        MessageCenter.MakeMessage("UIManager","change",-1);
        MessageCenter.MakeMessage("UIManager","change",-1);
      
        for(let manager of GeZiManager.YuanGong){
let a=new Message("",[65],-1)
            manager.ReceiveMessage(a)    
}
MessageCenter.MakeMessage("AM",turn.turn,"getZB")

for(let manager of GeZiManager.YuanGong){
  manager.getFar(4);
if(GeZiManager.BanMove.includes(manager.ZB)){

    
}else{  manager.red(); }
    }
    }
    state.ST=11


}



earthquake(){  if(this.qic(4-GeZiManager.free)){

let a=cc.find("Canvas/thingsManager/AnimalManager").getComponent(AnimalManager).YuanGong;

let b=new SHMessage("M",[65],1,GeZiManager.PCP,"mofa")
for(let manager of a) {

if(manager.DiXing=="grass"){manager.ReceiveMessage(b);}

   }











}}


wind(){

    if(this.qic(5-GeZiManager.free)){

 MessageCenter.MakeMessage("UIManager","change",5);
state.ST=12;






}

}




W2(){GeZiManager.face=2;MessageCenter.MakeMessage("UIManager","change",2.5);}
W4(){GeZiManager.face=4;MessageCenter.MakeMessage("UIManager","change",2.5);}
W6(){GeZiManager.face=6;MessageCenter.MakeMessage("UIManager","change",2.5);}
W8(){GeZiManager.face=8;MessageCenter.MakeMessage("UIManager","change",2.5);}

















}
