// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import ComponentBase from "../Message/ComponentBase";
import { Message } from "../Message/Message";
import character from "../character";
import turn from "../turn";

const {ccclass, property} = cc._decorator;

@ccclass
export default class NewClass extends ComponentBase {

    @property(cc.SpriteAtlas)
    Atlas:cc.SpriteAtlas=null;


start(){

    switch (this.node.parent.getComponent(character).Pturn) {
        case 1: this.node.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("1")
break;
case 2: this.node.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("2")
break;
case 3: this.node.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("3")
break;
case 4: this.node.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("4")
break;
case 5: this.node.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("5")
break;
case 6: this.node.getComponent(cc.Sprite).spriteFrame=this.Atlas.getSpriteFrame("6")
break;

    
        default:
            break;
    }
}


ReceiveMessage(message: Message) {
   let a=""+ this.node.parent.getComponent(character).qi;
    this.node.getChildByName("n").getComponent(cc.Label).string=a
this.node.opacity=233;


}


}
