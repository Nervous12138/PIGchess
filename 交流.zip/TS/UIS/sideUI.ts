// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import ComponentBase from "../Message/ComponentBase";
import GeZiManager from "../Message/GeZiManager";
import { Message } from "../Message/Message";
import character from "../character";
import turn from "../turn";
import heart from "./heart";
import HP from "./heart";

const {ccclass, property} = cc._decorator;

@ccclass
export default class sideUI extends ComponentBase {


   PC:character=null;
   MaxHP: number=2;
   HP:number=0;
qi:number=0;
   
   
   
   @property
    pturn:number=0;
    @property(cc.Prefab)
    heart:cc.Prefab=null;
    
    
    hearts:HP[]=[];
    @property(cc.SpriteAtlas)
    Atlas:cc.SpriteAtlas=null;


    start () {


GeZiManager.sideUI.push(this);



}

 

setS(){
    if(this.pturn==turn.turn-1){       
    switch (this.pturn) {
    case 1:this.PC=GeZiManager.P1;
        
        break;
        case 2:this.PC=GeZiManager.P2;
        
        break;
        case 3:this.PC=GeZiManager.P3;
        
        break;
        case 4:this.PC=GeZiManager.P4;
        
        break;
        case 5:this.PC=GeZiManager.P5;
        
        break;
        case 0:this.PC=GeZiManager.P6;
        
        break;
    default:
        break;
}
console.log(this.PC);
this.MaxHP=this.PC.MaxHP;
this.HP=this.PC.MaxHP;
this.qi=this.PC.qi;

for(let i=1;i<=this.MaxHP;i++){
    let HP=cc.instantiate(this.heart)
    HP.setParent(this.node.getChildByName("HP"))
  HP.getComponent(heart).DB=i;
 
}

for(let h of this.hearts){h.node.scaleX=h.node.scaleY;}

console.log("af")
this.setQi();
this.PC.UI.push(this);
}}


    setHP(){
        this.MaxHP=this.PC.MaxHP;
        this.HP=this.PC.HP;
    
    
    
    
    
    
    
    
        let n=this.MaxHP-this.HP;
    for(let mannger of this.hearts){
        mannger.to1();
        
    }
    
     for(let i=this.MaxHP;i>this.HP;i--){
    for(let mannger of this.hearts){
      if(mannger.DB==i){mannger.to0();}
    
    }
    
    
    
    }
    
    }



    setQi(){

        let a=""+ this.PC.qi;
        this.node.getChildByName("qin").getComponent(cc.Label).string=a

    }




    ReceiveMessage(message: Message) {
     this.setHP();
     this.setQi();
     }





}
