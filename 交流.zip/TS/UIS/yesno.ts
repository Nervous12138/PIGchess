// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import AnimalManager from "../Message/AnimalManager";
import ComponentBase from "../Message/ComponentBase";
import GeZiManager from "../Message/GeZiManager";
import MessageCenter from "../Message/MessageCenter";
import character from "../character";
import player from "../player";
import state from "../state";
import turn from "../turn";

const {ccclass, property} = cc._decorator;

@ccclass
export default class yesno extends ComponentBase {


   
   
   
   
 
   
   
   
    yes(){
switch (state.ST) {
    case 0: 
    MessageCenter.MakeMessage("UIManager","change",0)
   
cc.find("Canvas/thingsManager/AnimalManager").getComponent(AnimalManager).TP(turn.turn);

    
    turn.turn++;
  
   


if(player.Pturn==6){
 state.statechange();
}

switch(player.Pturn){
case 1:GeZiManager.bule.push(GeZiManager.GeZi)
break;
case 3:GeZiManager.bule.push(GeZiManager.GeZi)
break;
case 5:GeZiManager.bule.push(GeZiManager.GeZi)
break;
case 2:GeZiManager.red.push(GeZiManager.GeZi)
break;
case 4:GeZiManager.red.push(GeZiManager.GeZi)
break;
case 6:GeZiManager.red.push(GeZiManager.GeZi)
break;
}
        
        break;

case 1:MessageCenter.MakeSHMessage("AM",[GeZiManager.GeZi],GeZiManager.free,GeZiManager.PCP,"wuli");MessageCenter.MakeMessage("UIManager","change",1);
break;
case 2:cc.find("Canvas/thingsManager/AnimalManager").getComponent(AnimalManager).makeDL(GeZiManager.GeZi); MessageCenter.MakeMessage("UIManager","change",1);

break;

case 10:cc.find("Canvas/thingsManager/AnimalManager").getComponent(AnimalManager).makeFireball(GeZiManager.GeZi); MessageCenter.MakeMessage("UIManager","change",1)
break;
case 11:MessageCenter.MakeSHMessage("AM",[GeZiManager.GeZi],1,GeZiManager.PCP,"HP+");MessageCenter.MakeMessage("UIManager","change",1)
break;
case 12:
 for(let m of GeZiManager.WindSon){m.WDT()}  
switch (GeZiManager.face) {
    case 2:for(let i=1;i<=8;i++){
        GeZiManager.getWD(2);
        MessageCenter.MakeSHMessage("AM",GeZiManager.onY(i),1,GeZiManager.PCP,"wind");



    }
        
        break;
      
case 4:for(let i=1;i<=8;i++){
GeZiManager.getWD(4);
                MessageCenter.MakeSHMessage("AM",GeZiManager.onX(i),1,GeZiManager.PCP,"wind");
        
       
   
            }
                
                break;
case 6:for(let i=8;i>=1;i--){
    GeZiManager.getWD(6);
                    MessageCenter.MakeSHMessage("AM",GeZiManager.onX(i),1,GeZiManager.PCP,"wind");
            
            
 
                }
                    
                    break;
 case 8:for(let i=8;i>=1;i--){
    GeZiManager.getWD(8);
                        MessageCenter.MakeSHMessage("AM",GeZiManager.onY(i),1,GeZiManager.PCP,"wind");
                
                
                
                    }
                        
                        break;
    default:
        break;
}


for(let manager of GeZiManager.BanMove){
console.log(GeZiManager.BanMove)
    GeZiManager.DLBZ(manager);
}


GeZiManager.Ban=[];
MessageCenter.MakeMessage("UIManager","change",1)








    break;
    default:
        break;
}
   }

 
   no(){

   
    switch (state.ST) {          
   case 0: MessageCenter.MakeMessage("UIManager","change",-1)
break;
case 2: MessageCenter.MakeMessage("UIManager","change",3);
break;
case 10:cc.find("Canvas/thingsManager/AnimalManager").getComponent(AnimalManager).makeDL(GeZiManager.GeZi); MessageCenter.MakeMessage("UIManager","change",1)
case 11: MessageCenter.MakeMessage("UIManager","change",1);   MessageCenter.MakeMessage("AM",turn.turn,"getZB") ;MessageCenter.MakeSHMessage("AM",[GeZiManager.GeZi],3-GeZiManager.free,null,"Qi+");
break;
}

   }

delei(){
   GeZiManager.DL.push([GeZiManager.GeZi,3])
console.log(GeZiManager.DL);
}



 


   
}
