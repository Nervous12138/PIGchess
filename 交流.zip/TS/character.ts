import AnimalManager from "./Message/AnimalManager";
import ComponentBase from "./Message/ComponentBase";
import GeZiManager from "./Message/GeZiManager";
import { Message } from "./Message/Message";
import MessageCenter from "./Message/MessageCenter";
import UIManager from "./Message/UIManager";
import BUIManager from "./Message/xinxi/BUIManager";
import { SHMessage } from "./Message/xinxi/SHMessage";
import BUI from "./UIS/BUI";
import HUI from "./UIS/HUI";
import ghostUI from "./UIS/ghostUI";
import sideUI from "./UIS/sideUI";
import equiment from "./equipment";

import accessory from "./equipment/accessory/accessory";
import body from "./equipment/body/body";

import shops from "./equipment/shops";
import shose from "./equipment/shose/shose";
import Dun from "./equipment/weapon/Dun/Dun";

import weapon from "./equipment/weapon/weapon";
import player from "./player";
import realThing from "./realThing";
import state from "./state";
import turn from "./turn";




const { ccclass, property } = cc._decorator;

@ccclass
export default class character extends realThing {

   LST: number = 10;//生命状态，存活，濒死，死亡等等







   @property(cc.SpriteAtlas)
   Atlas: cc.SpriteAtlas = null;//通用图集



   weapon: cc.Node = null;//武器

   @property(accessory)
   accessory: accessory = null;//饰品

   @property(body)
   body: body = null;//身体（盔甲）

   @property(shose)
   shose: shose = null;//鞋子

   @property(cc.Prefab)
   HUI: cc.Prefab = null;//头顶上的血条

   @property(cc.Prefab)
   ghostUI: cc.Prefab = null;//死亡后的UI

   UI: ComponentBase[] = [];//自己的所有相关UI
   eqiupment: equiment[] = [];//自己的所有装备数组

   pre: cc.Prefab = null;

   walkWay: number = 1;//移动方式，默认1，推石头0.5，斜走等后续确定。
   Pturn: number = 0;//玩家序号，轮次
   MaxHP: number = 5;//最大生命值/生命值上限
   HP: number = 5;//当前生命值
   qi: number = 0;//气数
   faceTo = 2;//面向，与数字键相同
   mk: number = 0;//魔抗

   M: number = 1;//质量，用于判断风吹和击退等，补充玩法使用


   //下面是各种时间的触发集
   t1: ComponentBase[] = [];
   shop1: ComponentBase[] = [];
   shop2: ComponentBase[] = [];
   shop3: ComponentBase[] = [];
   attack1: ComponentBase[] = [];
   attack2: ComponentBase[] = [];
   attack3: ComponentBase[] = [];
   magic1: ComponentBase[] = [];
   magic2: ComponentBase[] = [];
   magic3: ComponentBase[] = [];
   magic4: ComponentBase[] = [];
   move1: ComponentBase[] = [];
   move2: ComponentBase[] = [];
   move3: ComponentBase[] = [];
   turn1: ComponentBase[] = [];
   turn2: ComponentBase[] = [];
   turn3: ComponentBase[] = [];
   behurt1: ComponentBase[] = [];
   behurt2: ComponentBase[] = [];
   behurt3: ComponentBase[] = [];
   hurt1: ComponentBase[] = [];
   hurt2: ComponentBase[] = [];
   hurt3: ComponentBase[] = [];
   dead1: ComponentBase[] = [];
   dead2: ComponentBase[] = [];
   t3: ComponentBase[] = [];




   TP(Pturn: number) {

      this.Pturn = Pturn;
      let ZB = GeZiManager.GeZi;
      this.ZB = ZB;
      GeZiManager.BanMove.push(this.ZB);
      if (this.Pturn % 2 == 0) { this.faceTo = 4 } else { this.faceTo = 6 }

      this.moveto(0, ZB);
      this.faceChange();


   }//开局放置生成的方法



   Bdead() {
      this.LST = 6;

      turn.Y.push(this);
      this.node.color = cc.color(155, 155, 155, 128);
      this.node.getChildByName("face").color = cc.color(155, 155, 155, 128);
   }//濒死状态


   dead() {

      this.LST = -1;

      GeZiManager.shanchu(GeZiManager.BanMove, this.ZB)
      player.endGame();
      this.qi = 0;
      this.node.getChildByName("face").active = false;
      this.node.getComponent(cc.Sprite).spriteFrame = this.Atlas.getSpriteFrame("gost");
      this.node.opacity = 100;
      this.node.getChildByName("HUI").active = false;
      this.node.getChildByName("qi").active = false;
      this.node.width = 175; this.node.height = 200;
      let ghost = cc.instantiate(this.ghostUI)
      ghost.setParent(this.node);
      console.log(this.Pturn + "gale")
      this.UI.push(ghost.getComponent(ghostUI))

   }//死亡状态



   Bd() {

      switch (this.LST) {

         case 10: this.LST = 10;
            break;

         case -1: this.LST = -1;
            break;
         case 0: this.LST = -1;

            break;

         default: this.LST -= 1;
            break;
      }

   }//濒死时每回合进行


   start() {
      let node = this.node.parent;
      node.getComponent(AnimalManager).addReceive(this);

      let HUI = cc.instantiate(this.HUI)
      HUI.setParent(this.node)

      this.pre = this.node.getComponent(shops).A000;
      console.log(this.pre);
      let weapon = cc.instantiate(this.pre);
      weapon.setParent(this.node);
      this.weapon = weapon;



      this.setXY();

      switch (this.Pturn) {
         case 1: GeZiManager.P1 = this;

            break;
         case 2: GeZiManager.P2 = this;

            break;
         case 3: GeZiManager.P3 = this;

            break;
         case 4: GeZiManager.P4 = this;

            break;
         case 5: GeZiManager.P5 = this;

            break;
         case 6: GeZiManager.P6 = this;

            break;

         default:
            break;
      }

      for (let m of GeZiManager.sideUI) { m.setS() }
   }

   changeE(i: number, pre: cc.Prefab) {

      switch (i) {
         case 1: this.weapon.destroy();
            let weapon = cc.instantiate(pre);
            weapon.setParent(this.node);
            this.weapon = weapon;
            break;

         default:
            break;
      }

   }//换装备















   turn4(arr: number[]): number[] {
      const transformationMap = {
         3: 1,
         6: 2,
         9: 3,
         2: 4,
         5: 5,
         8: 6,
         1: 7,
         4: 8,
         7: 9
      };
      for (let i = 0; i < arr.length; i++) {
         arr[i] = transformationMap[arr[i]] || arr[i];
      }
      return arr;
   }//顺时针转身


   turn6(arr: number[]): number[] {
      const transformationMap = {
         1: 3,
         2: 6,
         3: 9,
         4: 2,
         5: 5,
         6: 8,
         7: 1,
         8: 4,
         9: 7
      };
      for (let i = 0; i < arr.length; i++) {
         arr[i] = transformationMap[arr[i]] || arr[i];
      }
      return arr;
   }//逆时针转身


   PfaceFinal(faceTo: number, Pface: number[]) {
      let i = 0;
      switch (faceTo) {
         case 6: i = 1;
            break;
         case 8: i = 2;
            break;
         case 4: i = 3;
            break;
      }
      let PfaceFinal: number[] = [].concat(Pface)
      for (let n = 1; n <= i; n++) {
         this.turn6(PfaceFinal);
      }


      return PfaceFinal;

   }//最终盾牌/武器的防护面（原始保护面需要与自身面向进行匹配）








   DunDefenceSH(Dun1: weapon, MB: realThing, AT: weapon) {

      if (MB != null) {
         let Pface: number[] = [].concat(Dun1.Pface);

         if (this.PfaceFinal(this.faceTo, Pface).includes(MB.faceIs(this.ZB))) {

            Dun1.PD(AT.PJ);
            return Dun1.Pnumber;
         } else return 0;


      } else return 0;
   }//受到伤害前，伤害结算时进行的盾牌格挡



   getHurt(n: number) {

      this.HP -= n
      for (let mannger of this.UI) {
         if (mannger instanceof HUI) {
            mannger.setHP()
         }
         if (mannger instanceof sideUI) {
            mannger.setHP()
         }

      }


      if (this.HP <= 0 && this.LST == 10) { this.HP = 0; this.Bdead(); }



   }//受到伤害














   faceChange() {


      switch (this.faceTo) {
         case 2: this.node.getChildByName("face").angle = 180;
            break;
         case 4: this.node.getChildByName("face").angle = 90
            ;

            break;
         case 6: this.node.getChildByName("face").angle = 270;

            break;
         case 8: this.node.getChildByName("face").angle = 0;

            break;

         default: this.node.getChildByName("face").angle = 180;
            break;
      }

   }//转身后的显示同步，非数字箭头角色会删除






   UIchange(message: Message) {

      for (let mannger of this.UI) {

         mannger.ReceiveMessage(message);


      }
   }//UI同步信息










   ReceiveMessage(message: Message) {

      if (message instanceof SHMessage) {
         if (message.Command.includes(this.ZB) || message.Command[0] == 65) {

            switch (message.SHtype) {
               case "move": this.move(message.Content, 1); this.moveto(0.8, this.ZB); if (this.ZB == 8) { this.dead(); }
                  GeZiManager.DLBZ(this.ZB)
                  break;
               case "Qi+": if (message.Content < 0) { message.Content = 0 } this.qi += message.Content; this.UIchange(message);
                  break;
               case "Qi-": if (message.Content < 0) { message.Content = 0 } this.qi -= message.Content; this.UIchange(message);
                  break;
               case "Qi=": this.qi = message.Content; this.UIchange(message);
                  break;

               case "wuli": if (this.LST == -1) { } else { let n = message.Content - this.DunDefenceSH(this.weapon.getComponent(weapon), message.from, message.from.weapon.getComponent(weapon)); if (n < 0) { n = 0; } this.getHurt(n); }


                  break;
               case "mofa": if (this.LST == -1) { } else { let bn = message.Content - this.mk; if (bn < 0) { bn = 0; } this.getHurt(bn); }


                  break;
               case "HP=": if (this.LST == -1) { } else {
                  this.HP = message.Content; for (let mannger of this.UI) {
                     if (mannger instanceof HUI) {
                        mannger.setHP()
                     }
                  }
               }
                  break;
               case "HP+": if (this.LST == -1) { } else {
                  this.HP += message.Content; if (this.HP > this.MaxHP) { this.HP = this.MaxHP; } for (let mannger of this.UI) {
                     if (mannger instanceof HUI) {
                        mannger.setHP()
                     }
                  }

                  if (this.LST < 7 && this.LST > 0) {
                     this.node.color = cc.color(255, 255, 255, 255);
                     this.node.getChildByName("face").color = cc.color(255, 255, 255, 255);
                     this.LST = 10;

                     turn.Y.splice(turn.Y.indexOf(this));
                  }
               }
                  break;
               case "HP-": if (this.LST == -1) { } else {
                  this.HP -= message.Content; for (let mannger of this.UI) {
                     if (mannger instanceof HUI) {
                        mannger.setHP()
                     }
                  }
                  console.log("adas"); if (this.HP <= 0) { this.Bdead(); }
               }
                  break;
               case "getC": GeZiManager.PCP = this;//获取当前行动的角色
                  break;
               case "water": if (this.LST == -1) { } else {
                  if (GeZiManager.Ban.includes(this.ZB)) { } else {


                     switch (this.M) {
                        case -1:

                           break;
                        case 0: this.move(message.Content, 1 + GeZiManager.free); this.CMget(); this.moveto(1.5, this.ZB);

                           break;
                        case 1: this.move(message.Content, 1 + GeZiManager.free); this.CMget(); this.moveto(1.5, this.ZB);

                           break;
                        case 2: this.move(message.Content, 1 + GeZiManager.free); this.CMget(); this.moveto(1.5, this.ZB);

                           break;
                        case 8: this.move(message.Content, 1 + GeZiManager.free); this.CMget(); this.moveto(1.5, this.ZB);

                           break;
                        default:
                           break;
                     }
                  } if (this.ZB == 8) { this.dead(); }
               }
                  break;
               case "wind":
                  if (this.LST == -1) { } else {
                     if (GeZiManager.Ban.includes(this.ZB)) { } else {
                        switch (this.M) {
                           case -1:

                              break;
                           case 0:

                              break;
                           case 1: this.move(GeZiManager.face, 1); this.CMget(); this.moveto(1.5, this.ZB);

                              break;
                           case 2: this.move(GeZiManager.face, 2); this.CMget(); this.moveto(1.5, this.ZB);

                              break;
                           case 8: this.move(GeZiManager.face, 1); this.CMget(); this.moveto(1.5, this.ZB);

                              break;
                           default:
                              break;
                        }
                     }
                     if (this.y == 1 && GeZiManager.face == 6) {
                        while (this.ZB != 8) {
                           this.move(GeZiManager.face, 1);
                           this.CMget(); this.moveto(1.5, this.ZB); if (GeZiManager.BanMove.includes(this.findGe(GeZiManager.face, 1))) { break; }
                        }
                     }
                     if (this.y == 8 && GeZiManager.face == 4) {
                        while (this.ZB != 56) {
                           this.move(GeZiManager.face, 1);
                           this.CMget(); this.moveto(1.5, this.ZB); if (GeZiManager.BanMove.includes(this.findGe(GeZiManager.face, 1))) { break; }
                        }
                     }
                     if (this.x == 8 && GeZiManager.face == 2) {
                        while (this.ZB != 8) {
                           this.move(GeZiManager.face, 1);
                           this.CMget(); this.moveto(1.5, this.ZB); if (GeZiManager.BanMove.includes(this.findGe(GeZiManager.face, 1))) { break; }
                        }
                     }
                     if (this.x == 1 && GeZiManager.face == 2) {
                        while (this.ZB != 1) {
                           this.move(GeZiManager.face, 1);
                           this.CMget(); this.moveto(1.5, this.ZB); if (GeZiManager.BanMove.includes(this.findGe(GeZiManager.face, 1))) { break; }
                        }
                     }


                     if (this.ZB == 8) { this.dead(); }
                  }
                  break;
               default:
                  break;




            }

         }
      } else {
         this.DO(message);
      }
   }/*受到信息后的各种行动（SHMessage与Message的区别主要在于对象，前者通过坐标指定角色或物品，改变场上的物体关系，后者基本上只对自己和自己的UI生效
（包括一些静态类中的事件））



*/




   DO(message: Message) {

      if (this.Pturn == turn.turn) {


         switch (message.Content) {

            case "ST":
               GeZiManager.Bu = []; this.ST();//更新UI与状态

               break;

            case "turn6": this.faceTo = this.turn6([this.faceTo])[0]; this.faceChange(); this.ST();//逆时针转身
               break;

            case "turn4": this.faceTo = this.turn4([this.faceTo])[0]; this.faceChange(); this.ST();//顺时针转身
               break;

            case "walk": switch (this.walkWay) {


               case 1: this.move(this.faceTo, 1)

                  this.moveto(0.8, this.ZB)
                  GeZiManager.DLBZ(this.ZB)

                  break;
               case 0.5: MessageCenter.MakeSHMessage("AM", [this.findGe(this.faceTo, 1)], this.faceTo, this, "move"); MessageCenter.MakeSHMessage("AM", [this.ZB], 5 - this.HP, this, "Qi-"); MessageCenter.MakeSHMessage("AM", [this.ZB], 1, this, "Qi-"); this.move(this.faceTo, 1)
                  this.moveto(0.8, this.ZB);

                  break;
               default:
                  break;
            }
               this.ST();//点击移动按钮的后续，取决于移动方式

               break;
            case "Qi+": this.qi += 1; this.UIchange(message); this.ST();
               break;

            case "attack": this.weapon.getComponent(weapon).attack(); this.ST();
               break;

            case "changE1": this.changeE(1, message.Command);
               break;
            case "getZB": GeZiManager.GeZi = this.ZB;//获得当前行动角色的坐标
               break;

            case "getQi": GeZiManager.Qi = this.qi;
               break;

            case "getHP": GeZiManager.HP = this.HP;
               break;

            case "getC": GeZiManager.PCP = this;
               break;

            default: console.log(GeZiManager.BanMove);

         }


      }













   }


   ST() {

if(this.DiXing=="water"){   MessageCenter.MakeMessage("BUI", [3], "Ban");}else{ MessageCenter.MakeMessage("BUI", [3], "Use");}
      if (GeZiManager.rock.includes(this.findGe(this.faceTo, 1))) { this.walkWay = 0.5; MessageCenter.MakeMessage("BUI", [2], "change0.5"); } else {
         this.walkWay = 1
         MessageCenter.MakeMessage("BUI", [2], "change1")
         if (this.GX(this.faceTo)) {
            ;
            MessageCenter.MakeMessage("BUI", [2], "Ban");
         } else { MessageCenter.MakeMessage("BUI", [2], "Use"); }
      }
   }//更新状态





   GX(face: number) {
      this.CMget();

      if (this.CanTmove.includes(face)) {

         return true;
      } else return false;




   }//更新附近位置关系












   BUI() {
      console.log(this.LST);
      switch (this.LST) {
         case 10: MessageCenter.MakeMessage("BUI", [1, 2, 3, 4, 5, 0], "Use"); MessageCenter.MakeMessage("AM", turn.turn, "ST");
            break;


         case -1: MessageCenter.MakeMessage("BUI", [2, 3, 5, 0], "Ban"); this.node.getComponent(cc.Sprite).spriteFrame = this.Atlas.getSpriteFrame("picking gost"); this.node.opacity = 166; this.node.width = 175; this.node.height = 230;
            break;


         default: MessageCenter.MakeMessage("UIManager", "change", 0); if (turn.turn == this.Pturn) { turn.turn++; turn.turnpass(); }
            state.ST = 1;
            break;
      }




   }//回合开始时判断UI

}












