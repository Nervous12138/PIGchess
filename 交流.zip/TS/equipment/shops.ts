// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import ComponentBase from "../Message/ComponentBase";
import turn from "../turn";

const {ccclass, property} = cc._decorator;

@ccclass
export default class shop extends ComponentBase {



    @property(cc.Prefab)
public  A000:cc.Prefab=null;
@property(cc.Prefab)
public  A110:cc.Prefab=null;
public  A121:cc.Prefab=null;
public  A122:cc.Prefab=null;
public  A123:cc.Prefab=null;

@property(cc.Prefab)
public  A130:cc.Prefab=null;
@property(cc.Prefab)
public  A150:cc.Prefab=null;


@property(cc.Prefab)
public  A210:cc.Prefab=null;
@property(cc.Prefab)
public  A231:cc.Prefab=null;
@property(cc.Prefab)
public  A232:cc.Prefab=null;
@property(cc.Prefab)
public  A251:cc.Prefab=null;
@property(cc.Prefab)
public  A252:cc.Prefab=null;


@property(cc.Prefab)
public  A310:cc.Prefab=null;


@property(cc.Prefab)
public  A331:cc.Prefab=null;

@property(cc.Prefab)
public  A332:cc.Prefab=null;
@property(cc.Prefab)
public  A350:cc.Prefab=null;




 A1:cc.Prefab=null;

  A2:cc.Prefab=null;

  A3:cc.Prefab=null;

  A4:cc.Prefab=null;





















            }
           
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        










