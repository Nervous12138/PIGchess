// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import GeZiManager from "../../../Message/GeZiManager";
import { Message } from "../../../Message/Message";
import MessageCenter from "../../../Message/MessageCenter";
import character from "../../../character";
import state from "../../../state";
import Dao from "./Dao";

const { ccclass, property } = cc._decorator;

@ccclass
export default class A120 extends Dao {


  level: number = 2
  TheNumber: string = "A130";
  Aface: number[] = [1, 2, 3];

  ac() {
    let a = [2, 4, 6, 8]
    if (a.includes(this.node.parent.getComponent(character).faceIs(GeZiManager.GeZi))) {
      GeZiManager.free = 2
    } else { GeZiManager.free = 1 }






  }
  attack() {

    GeZiManager.qing();
    MessageCenter.MakeMessage("UIManager", "change", -1);
    state.ST = 1
    let AF = [].concat(this.Aface);
    let i = 0;
    switch (this.node.parent.getComponent(character).faceTo) {
      case 6: i = 1;
        break;
      case 8: i = 2;
        break;
      case 4: i = 3;
        break;
    }


    for (let n = 1; n <= i; n++) {
      this.turn6(AF);

    }
    let an: number[] = [];
    for (let mannger of AF) {



      an.push(this.node.parent.getComponent(character).findGe(mannger, 1));

    }

    GeZiManager.GeZis = [].concat(an);

    let c = new Message("", GeZiManager.GeZis, 1);
    for (let manager of GeZiManager.YuanGong) {


      manager.red();

      manager.ReceiveMessage(c);

    }


  }//像有多个目标的选择其一的武器插入UI转换，做这类武器时私聊我









}
