// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import GeZiManager from "../../../Message/GeZiManager";
import character from "../../../character";
import A130 from "./A130";

const {ccclass, property} = cc._decorator;

@ccclass
export default class A150 extends A130 {
  TheNumber:string = "A150";
    ac(){
        let a=[2,4,6,8]
          if(a.includes(this.node.parent.getComponent(character).faceIs(GeZiManager.GeZi))) {
           GeZiManager.free=3
          }else{GeZiManager.free=2}
}}
