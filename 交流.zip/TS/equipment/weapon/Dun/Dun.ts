// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import { Message } from "../../../Message/Message";
import character from "../../../character";
import turn from "../../../turn";
import weapon from "../weapon";




const { ccclass, property } = cc._decorator;

@ccclass
export default class Dun extends weapon {

    Pface: number[] = [2];
    Ptype: String[] = [];
    Pnumber: number = 1;
    BH: boolean = false;
    turn: number = 0;

    PD(n: number) {
        this.Pnumber -= n;
        this.BH = true;

    }









    start() {
        turn.YuanGong.push(this);
        this.node.parent.getComponent(character).eqiupment.push(this);
    }



    turnPass() {


        if (this.BH == true) {
            this.turn++;

            if (this.turn == 6) { this.BH = false; this.turn = 0; }
        }








    }





}
