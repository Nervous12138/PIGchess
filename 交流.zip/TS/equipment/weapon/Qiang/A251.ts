// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import A231 from "./A231";

const {ccclass, property} = cc._decorator;

@ccclass
export default class A251 extends A231 {
  TheNumber:string = 'A251';
  SH: number=3;




}
