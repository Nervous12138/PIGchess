// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import Qiang from "./Qiang";

const {ccclass, property} = cc._decorator;

@ccclass
export default class A252 extends Qiang{
   TheNumber:string = 'A252';
   SH: number=3;
   PJ: number=1;


}
