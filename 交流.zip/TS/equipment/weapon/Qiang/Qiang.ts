// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import GeZiManager from "../../../Message/GeZiManager";
import MessageCenter from "../../../Message/MessageCenter";
import character from "../../../character";
import weapon from "../weapon";



const { ccclass, property } = cc._decorator;

@ccclass
export default class Qiang extends weapon {
  BT: boolean = true;//是否耗费子弹
  ptr: number = 1;//穿透数+1
  BTS: number = 1;//子弹数


  attack() {
    if (this.BT) {
      if (this.BTS == 0) { this.BTS++ } else { this.attack2(); }





    } else { this.attack2(); }

  }//枪类武器攻击分步，attack是判断子弹选择是否装弹，attack2是正式攻击



  attack2() {
    let AF = [].concat(this.Aface);
    let i = 0;
    switch (this.node.parent.getComponent(character).faceTo) {
      case 6: i = 1;
        break;
      case 8: i = 2;
        break;
      case 4: i = 3;
        break;
    }


    for (let n = 1; n <= i; n++) {
      this.turn6(AF);

    }


    let A2 = GeZiManager.line(this.node.parent.getComponent(character).ZB, this.ptr, AF[0], GeZiManager.BanMove);


    MessageCenter.MakeSHMessage("AM", A2, this.SH, this.node.parent.getComponent(character), "wuli")
    this.BTS--
  }





}//GeZiManager.line这个方法是判断直线上目标的


