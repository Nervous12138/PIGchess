// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import MessageCenter from "../../Message/MessageCenter";
import character from "../../character";
import equipment from "../../equipment";
import equiment from "../../equipment";
import turn from "../../turn";



const { ccclass, property } = cc._decorator;

@ccclass
export default class weapon extends equipment {


  Atype = "wuli"
  Aface: number[] = [2];//攻击面（只适用于近战角色）
  Pface: number[] = [0];//防御面，默认朝下
  Ptype: String[] = [];//防御类型
  Pnumber: number = 0;
  PJ: number = 0;//破甲
  SH = 1;//伤害
  Wtype: number;
  level: number;//武器等级
  TheNumber: string = 'A000';//编号，用于识别武器



  turn6(arr: number[]): number[] {
    const transformationMap = {
      1: 3,
      2: 6,
      3: 9,
      4: 2,
      5: 5,
      6: 8,
      7: 1,
      8: 4,
      9: 7
    };
    for (let i = 0; i < arr.length; i++) {
      arr[i] = transformationMap[arr[i]] || arr[i];
    }
    return arr;
  }//通用校对的基本方法，不用理会




  start() {

  }

  PD(PJ: number) {

  }//盾类武器的被破盾机制





  ac() {



  }//特殊的被动效果

  FJ() { }//受到攻击后的反击效果




  attack() {
    let AF = [].concat(this.Aface);
    let i = 0;
    switch (this.node.parent.getComponent(character).faceTo) {
      case 6: i = 1;
        break;
      case 8: i = 2;
        break;
      case 4: i = 3;
        break;
    }


    for (let n = 1; n <= i; n++) {
      this.turn6(AF);

    }
    let an: number[] = [];
    for (let mannger of AF) {



      an.push(this.node.parent.getComponent(character).findGe(mannger, 1));

    }
    MessageCenter.MakeSHMessage("AM", an, this.SH, this.node.parent.getComponent(character), "wuli")
  }//攻击，每个武器不同，这个是空手的攻击的攻击方法，角色攻击调用武器的攻击方法
}
