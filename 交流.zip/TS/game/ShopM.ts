// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import ComponentBase from "../Message/ComponentBase";
import turn from "../turn";

const {ccclass, property} = cc._decorator;

@ccclass
export default class shopM extends ComponentBase {

 static   A1n:number[]=[2,2];
 static   A2n:number[]=[2,2];
 static   A3n:number[]=[2,2];
  static  A4n:number[]=[1,2];
  static  A5n:number[][]=[[]]; 
    
    
    
    
    
    
    start(){
        turn.YuanGong.push(this);
    }
    
    
    
    
    
    turnPass(){
        switch (turn.day) {
            case 1:
                switch (turn.round){
                   case 3:shopM.A1n[1]=1;shopM.A2n[1]=1;shopM.A3n[1]=1;
    
    
    
    
}
        }}}