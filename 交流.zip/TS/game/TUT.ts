// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import ComponentBase from "../Message/ComponentBase";
import GeZiManager from "../Message/GeZiManager";
import MessageCenter from "../Message/MessageCenter";
import { SHMessage } from "../Message/xinxi/SHMessage";
import turn from "../turn";

const {ccclass, property} = cc._decorator;

@ccclass
export default class TUT extends ComponentBase {

    
    start () {
turn.YuanGong.push(this)
    }




turnPass(){
 switch (turn.day) {
  case 1: this.F110();this.F111();this.TuW();
    
    break;
 
  default:
    break;
 }
  


}



F110(){

if((turn.turn==6&&turn.round==4)||(turn.turn==6&&turn.round==16)){


    MessageCenter.MakeSHMessage("AM",[65],2,null,"Qi+");
}



}


F111(){
  if(turn.round%3==0&&GeZiManager.Bu.includes(2)){
GeZiManager.PCP.qi+=1;console.log(""+GeZiManager.PCP.qi+",")
let a=new SHMessage("AM",[GeZiManager.GeZi],1,null,"Qi+")
GeZiManager.PCP.UIchange(a);
}

  
}




TuW(){

  if(turn.turn==1){
let a=[2,3,4,5,6,7]
 let b=[]  
for(let i=0;i<=5;i++){

if(GeZiManager.BanMove.includes(a[i])==false){b.push(a[i])}}
  

  let randomIndex = Math.floor(Math.random() *b.length);
  let c = b[randomIndex];
if(GeZiManager.BanMove.includes(1)){
MessageCenter.MakeSHMessage("AM",[1],1,null,"getC");
GeZiManager.PCP.To(c);
}
}
}
}
