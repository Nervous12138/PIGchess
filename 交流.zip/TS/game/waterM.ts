// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import ComponentBase from "../Message/ComponentBase";
import GeZiManager from "../Message/GeZiManager";
import MessageCenter from "../Message/MessageCenter";
import turn from "../turn";

const {ccclass, property} = cc._decorator;

@ccclass
export default class waterM extends ComponentBase {

W2:number[]=[7,6,5,4,3,2];
W4:number[]=[9,17,25,33,41,49,57];
W6:number[]=[16,24,32,40,48,56];
W8:number[]=[58,59,60,61,62,63];
start(){turn.YuanGong.push(this)   
}

turnPass(){
GeZiManager.free=0;
    if(turn.turn==1){



for(let manager of this.W2){

    MessageCenter.MakeSHMessage("AM",[manager],6,null,"water")

}

for(let manager of this.W4){

    MessageCenter.MakeSHMessage("AM",[manager],2,null,"water")

}


for(let manager of this.W6){

    MessageCenter.MakeSHMessage("AM",[manager],2,null,"water")

}
for(let manager of this.W8){

    MessageCenter.MakeSHMessage("AM",[manager],4,null,"water")

} 



}



}




    
}
