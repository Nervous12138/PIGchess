import ComponentBase from "./Message/ComponentBase";
import GeZiManager from "./Message/GeZiManager";


const {ccclass, property} = cc._decorator;

@ccclass
export default class player extends ComponentBase {
   
static Pturn:number=1;
   
   


     onLoad () {}

    start () {








    }

 
    static endGame(){

if(GeZiManager.P1.LST+GeZiManager.P3.LST+GeZiManager.P5.LST==-3){for (let m of GeZiManager.label){m.redWin()}}else if(GeZiManager.P2.LST+GeZiManager.P4.LST+GeZiManager.P6.LST==-3){for (let m of GeZiManager.label){m.blueWin()}}







    
}}
