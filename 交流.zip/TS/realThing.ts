import AnimalManager from "./Message/AnimalManager";
import ComponentBase from "./Message/ComponentBase";
import GeZiManager from "./Message/GeZiManager";
import { Message } from "./Message/Message";
import { SHMessage } from "./Message/xinxi/SHMessage";




const { ccclass, property } = cc._decorator;

@ccclass
export default class realThing extends ComponentBase {
  faceTo: number;//朝向
  faceHurt: number;//受伤面
  speed: number;//移速
  walkWay: number = 0;//移动方式
  CanTmove: number[] = [];//不能移动或者移动受阻的方位
  weapon: cc.Node = null;//武器
  HP: number = 0;
  WD: Boolean = false;//防风
  M: number = 0;
  ghost: Boolean = false;//是否有碰撞体积
  DiXing: string = "grass";//所处地形
  ZB: number = 0;//坐标，1到64
  y: number = 0;//y，从下往上，1到8
  x: number = 0;//x，从左往右，1到8
  tt: string = "tree"// 类型 

  start() {
    this.setXY();


  }








  To(ZB: number) {
    GeZiManager.shanchu(GeZiManager.BanMove, this.ZB);
    this.ZB = ZB;
    this.CMget();

    this.setXY();
    if (this.WD) { GeZiManager.shanchu(GeZiManager.WD, this.ZB); }


    this.moveto(0.8, this.ZB);
  }//移动到某个坐标







  move(face: number, dis: number) {
    if (this.tt == "rock") { GeZiManager.shanchu(GeZiManager.rock, this.ZB) }
    if (GeZiManager.BanMove.includes(this.findGe(face, 1)) == false) {
      for (let i = 0; i < dis; i++) {
        if (GeZiManager.BanMove.includes(this.findGe(face, 1))) { } else {
          GeZiManager.shanchu(GeZiManager.BanMove, this.ZB);
          if (this.findGe(face, 1) != 65) {
            this.ZB = this.findGe(face, 1)
          }
          if (this.WD) {
            GeZiManager.shanchu(GeZiManager.WD, this.ZB);

          }







        }
      }



      if (this.tt == "rock" && this.ZB == 8) { this.node.active = false; GeZiManager.shanchu(GeZiManager.BanMove, 8); GeZiManager.shanchu(GeZiManager.rock, 8); }



    }


    this.setXY();


  }//朝某个方向移动dis格






  setXY() {

    if (this.ZB % 8 == 0) { this.x = 8 } else { this.x = this.ZB % 8; }
    this.y = Math.ceil(this.ZB / 8);
    let targetScale
    switch (this.y) {

      case 1: targetScale = 1;
        break;
      case 2: targetScale = 0.95;
        break;
      case 3: targetScale = 0.9;
        break;
      case 4: targetScale = 0.85;
        break;
      case 5: targetScale = 0.8;
        break;
      case 6: targetScale = 0.75;
        break;
      case 7: targetScale = 0.7;
        break;
      case 8: targetScale = 0.65;
        break;




      default:
        break;



    }
    const scaleAction = cc.scaleTo(0.8, targetScale);
    const callback = cc.callFunc(() => {
      this.enabled = false;
    });
    const sequence = cc.sequence(scaleAction, callback);
    this.node.runAction(sequence);


    this.node.zIndex = (9 - this.y);
    if (this.ghost == false && this.HP >= 0) {
      GeZiManager.BanMove.push(this.ZB)
    }


    if (this.WD) { GeZiManager.WD.push(this.ZB); }

    if (this.x == 1 || this.x == 8) { this.DiXing = "water" } else if (this.y == 1 || this.y == 8) { this.DiXing = "water" } else { this.DiXing = "grass" }

    if (this.tt == "rock") { GeZiManager.rock.push(this.ZB) }
  }//保存新的xy数据并且调整大小（根据透视原理）


  findGe(face: number, i: number) {
    let n = 0;
    let a = this.ZB;
    for (let b = 0; b < i; b++) {
      if ((this.x === 1) && (face === 4)) { n = 65 } else if ((this.x === 8) && (face === 6)) { n = 65; } else if ((this.y === 1) && (face === 2)) { n = 65; } else if ((this.y === 8) && (face === 8)) { n = 65; }
      else {

        switch (face) {
          case 1: n = a - 9
            break;

          case 2: n = a - 8
            break;

          case 3: n = a - 7
            break;
          case 4: n = a - 1
            break;
          case 5: n = a
            break;
          case 6: n = a + 1
            break;
          case 7: n = a + 7
            break;
          case 8: n = a + 8
            break;
          case 9: n = a + 9
            break;


        }
        a = n;
      }


    }

    return n;
  }//获取某个方向上第dis格的坐标







  CMget() {

    this.CanTmove = [];
    for (let i = 1; i <= 9; i++) {

      if (GeZiManager.BanMove.includes(this.findGe(i, 1))) {

        this.CanTmove.push(i);

      }
    }

  }//更新新的阻挡数组CanTmove（里面是方位而不是具体坐标）










  faceIs(ZB: number) {

    let y;
    let x;

    if (ZB % 8 == 0) { x = 8 } else { x = ZB % 8; }
    y = Math.ceil(ZB / 8);








    if (this.x == x && this.y == y) {
      return 5; // 表示位置在原点
    } else if (this.x == x) {
      return this.y > y ? 8 : 2; // 表示位置在Y轴上
    } else if (this.y == y) {
      return this.x > x ? 6 : 4; // 表示位置在X轴上
    } else {
      if (this.x > x) {
        return this.y > this.y ? 9 : 3; // 表示位置在第一或第四象限
      } else {
        return this.y > this.y ? 7 : 1; // 表示位置在第二或第三象限
      }
    }
  }//判断某个坐标与自身的位置关系，返回1到9的一个方位






















  moveto(time: number, ZB: number) {

    let point;
    switch (ZB) {
      case 0: point = new cc.Vec2(0, 0);

        break;


      case 1: point = new cc.Vec2(300, 65);
        break;
      case 2: point = new cc.Vec2(634, 65);
        break;
      case 3: point = new cc.Vec2(906, 65);
        break;
      case 4: point = new cc.Vec2(1188, 65);
        break;
      case 5: point = new cc.Vec2(1485, 65);
        break;
      case 6: point = new cc.Vec2(1774, 65);
        break;
      case 7: point = new cc.Vec2(2058, 65);
        break;
      case 8: point = new cc.Vec2(2228, 65);
        break;



      case 9: point = new cc.Vec2(445, 270);
        break;
      case 10: point = new cc.Vec2(684, 270); console.log("10");
        break;
      case 11: point = new cc.Vec2(950, 270);
        break;
      case 12: point = new cc.Vec2(1212, 270);
        break;
      case 13: point = new cc.Vec2(1465, 270);
        break;
      case 14: point = new cc.Vec2(1724, 270);
        break;
      case 15: point = new cc.Vec2(1983, 270);
        break;
      case 16: point = new cc.Vec2(2203, 270);
        break;


      case 17: point = new cc.Vec2(445, 436);
        break;
      case 18: point = new cc.Vec2(684, 436);
        break;
      case 19: point = new cc.Vec2(950, 436);
        break;
      case 20: point = new cc.Vec2(1212, 436);
        break;
      case 21: point = new cc.Vec2(1465, 436);
        break;
      case 22: point = new cc.Vec2(1724, 436);
        break;
      case 23: point = new cc.Vec2(1983, 436);
        break;
      case 24: point = new cc.Vec2(2203, 436);
        break;



      case 25: point = new cc.Vec2(572, 592);
        break;
      case 26: point = new cc.Vec2(792, 592);
        break;
      case 27: point = new cc.Vec2(1008, 592);
        break;
      case 28: point = new cc.Vec2(1229, 592);
        break;
      case 29: point = new cc.Vec2(1439, 592);
        break;
      case 30: point = new cc.Vec2(1660, 592);
        break;
      case 31: point = new cc.Vec2(1886, 592);
        break;
      case 32: point = new cc.Vec2(2083, 592);
        break;






      case 33: point = new cc.Vec2(654, 740);
        break;
      case 34: point = new cc.Vec2(843, 740);
        break;
      case 35: point = new cc.Vec2(1039, 740);
        break;
      case 36: point = new cc.Vec2(1241, 740);
        break;
      case 37: point = new cc.Vec2(1431, 740);
        break;
      case 38: point = new cc.Vec2(1630, 740);
        break;
      case 39: point = new cc.Vec2(1831, 740);
        break;
      case 40: point = new cc.Vec2(2018, 740);
        break;





      case 41: point = new cc.Vec2(719, 883);
        break;
      case 42: point = new cc.Vec2(888, 883);
        break;
      case 43: point = new cc.Vec2(1067, 883);
        break;
      case 44: point = new cc.Vec2(1246, 883);
        break;
      case 45: point = new cc.Vec2(1423, 883);
        break;
      case 46: point = new cc.Vec2(1600, 883);
        break;
      case 47: point = new cc.Vec2(1784, 883);
        break;
      case 48: point = new cc.Vec2(1958, 883);
        break;




      case 49: point = new cc.Vec2(765, 995);
        break;
      case 50: point = new cc.Vec2(924, 995);
        break;
      case 51: point = new cc.Vec2(1088, 995);
        break;
      case 52: point = new cc.Vec2(1252, 995);
        break;
      case 53: point = new cc.Vec2(1412, 995);
        break;
      case 54: point = new cc.Vec2(1578, 995);
        break;
      case 55: point = new cc.Vec2(1742, 995);
        break;
      case 56: point = new cc.Vec2(1900, 995);
        break;



      case 57: point = new cc.Vec2(815, 1080);
        break;
      case 58: point = new cc.Vec2(956, 1096);
        break;
      case 59: point = new cc.Vec2(1107, 1096);
        break;
      case 60: point = new cc.Vec2(1260, 1096);
        break;
      case 61: point = new cc.Vec2(1410, 1096);
        break;
      case 62: point = new cc.Vec2(1562, 1096);
        break;
      case 63: point = new cc.Vec2(1708, 1096);
        break;
      case 64: point = new cc.Vec2(1848, 1096);
        break;
      case 65:
        break;






      default: point = new cc.Vec2(300, 65);
        break;
    }




    cc.tween(this.node)
      .to(time, { position: point })
      .start();
  }//在time秒内把物体移动到坐标对应的实际位置







  ReceiveMessage(message: Message) {
    if (message instanceof SHMessage) {
      if (message.Command.includes(this.ZB) || message.Command == 65) {

        switch (message.SHtype) {
          case "move": this.move(message.Content, 1); this.moveto(0.6, this.ZB); GeZiManager.DLBZ(this.ZB); this.CMget();
            break;


          case "wuli": this.HP -= message.Content - 1; if (this.HP <= 0) { this.node.active = false; GeZiManager.shanchu(GeZiManager.BanMove, this.ZB); GeZiManager.shanchu(GeZiManager.BanMove, this.ZB); } console.log(this.HP)


            break;
          case "mofa": this.HP -= message.Content; if (this.HP <= 0) { this.node.active = false; GeZiManager.shanchu(GeZiManager.BanMove, this.ZB); GeZiManager.shanchu(GeZiManager.BanMove, this.ZB); } console.log(this.HP)


            break;
          case "wind": if (GeZiManager.Ban.includes(this.ZB)) { } else {
            switch (this.M) {
              case -1:

                break;
              case 0:

                break;
              case 1: this.move(GeZiManager.face, 1); this.CMget(); this.moveto(1.5, this.ZB);

                break;
              case 2: this.move(GeZiManager.face, 2); this.CMget(); this.moveto(1.5, this.ZB);

                break;
              case 8: this.move(GeZiManager.face, 1); this.CMget(); this.moveto(1.5, this.ZB);

                break;
              default:
                break;
            }
          }
            break;
          default:
            break;
        }






      }

    }
  }
}