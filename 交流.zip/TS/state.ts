// Learn TypeScript:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/2.4/manual/en/scripting/life-cycle-callbacks.html

import ComponentBase from "./Message/ComponentBase";
import GeZiManager from "./Message/GeZiManager";
import MessageCenter from "./Message/MessageCenter";
import player from "./player";
import turn from "./turn";

const {ccclass, property} = cc._decorator;

@ccclass
export default class state extends ComponentBase {

   
static state:number=0;
static ST:number=0;

static Pchange(){
if(state.state==0){
    if(player.Pturn==turn.turn){
        MessageCenter.MakeMessage("UIManager","change",-1)
        
        GeZiManager.qing();

        if(turn.turn%2==0){GeZiManager.redBan();}else{GeZiManager.blueBan();}
       
       
       
       
    }else {  MessageCenter.MakeMessage("UIManager","change",0)}
}else{
    if(player.Pturn==turn.turn){  MessageCenter.MakeMessage("UIManager","change",1)
 
    MessageCenter.MakeMessage("AM",turn.turn,"getC"); 
if(turn.turn==player.Pturn){
    GeZiManager.PCP.BUI();}

}else {  MessageCenter.MakeMessage("UIManager","change",0)}






}




}

static statechange(){
state.state=1;
    MessageCenter.MakeMessage("UIManager","change",0)
turn.turn=1;
if(player.Pturn==1){
    MessageCenter.MakeMessage("UIManager","change",1)
}


}

start(){
 GeZiManager.blueBan();   
}




}
