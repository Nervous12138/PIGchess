import ComponentBase from "./Message/ComponentBase";
import ManagerBase from "./Message/ManagerBase";
import { Message } from "./Message/Message";
import character from "./character";


const {ccclass, property} = cc._decorator;

@ccclass
export default class turn extends ManagerBase {
 static  DorN:String="day"
   
 static  day: number = 1;
 
  static round: number = 1;
  
  static  turn: number = 1;
   
  static Y:character[]=[];
static TimePass(){
   console.log(turn.round)
  if(turn.turn==7){
turn.turn=1
turn.round++;
  

}
   if(turn.round%13==1&&turn.round!=1){
   turn.day++;
       }    
  if(turn.round- (turn.day-1)*12==7){
turn.DorN="dusk"
}else if(turn.round- (turn.day-1)*12<7)
{turn.DorN="day"
}else if(turn.round- (turn.day-1)*12>7)
{turn.DorN="nigth"}




  } 
    
static YuanGong: ComponentBase[]=[];

 

static turnpass(){


  
  turn.TimePass();

let a=new Message("",[65],-1)
if(turn.YuanGong[0]!=null){
for(let manager of turn.YuanGong){



  manager.turnPass();


}}

for(let m of turn.Y){
if(m.LST<7&&m.LST>0){m.LST-=1;}
if(m.LST==0){m.dead();}
console.log(""+m.Pturn+m.LST)

}







}


}
    
    
   
